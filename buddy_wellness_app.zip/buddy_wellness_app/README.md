# Buddy Wellness / WellMind AI

An AI-powered Daily Wellness & Habit Tracker application for Android and iOS, with a Flutter Web Admin Panel and a marketing landing page.

## Table of Contents
- [Introduction](#introduction)
- [Features](#features)
- [Architecture](#architecture)
- [Setup Guide](#setup-guide)
- [Admin Panel](#admin-panel)
- [Monetization](#monetization)
- [Deployment](#deployment)
- [Maintenance](#maintenance)
- [API Documentation](#api-documentation)
- [Contributing](#contributing)
- [License](#license)

## Introduction
Buddy Wellness is designed to help users cultivate healthy habits, track their wellness journey, and receive personalized insights through the power of Artificial Intelligence. This comprehensive solution includes a mobile application (Android & iOS), a web-based admin panel for managing users and content, and a static landing page for marketing and user acquisition.

## Features

### Mobile Application (Flutter)
- **Authentication**: Secure user registration and login (Email/Password, Google).
- **Onboarding**: Guided first-time user experience.
- **Dashboard**: Overview of daily habits, wellness score, mood, streaks, and AI suggestions.
- **Habit Management**: Create, track, update, and delete habits with reminders and scheduling.
- **AI Recommendations**: Personalized wellness recommendations and insights powered by OpenAI.
- **Streak System**: Gamified motivation through habit streaks and achievements.
- **Analytics**: Visual representation of user progress, habit completion rates, and wellness trends.
- **User Profile**: Manage personal information, goals, and app preferences.
- **Settings**: Configure app settings, notifications, and privacy controls.
- **Notifications**: Timely reminders and motivational messages.

### Admin Panel (Flutter Web)
- **User Management**: View, edit, and manage user accounts.
- **Habit Oversight**: Monitor overall habit creation and completion trends.
- **Analytics Dashboard**: Comprehensive analytics for app usage, user engagement, and wellness metrics.
- **Content Management**: Manage AI prompts, motivational quotes, and app content.
- **Settings**: Configure global app settings and features.

### Landing Website (HTML/CSS/JS)
- **SEO Optimized**: Designed for search engine visibility.
- **Responsive Design**: Optimized for various devices (desktop, tablet, mobile).
- **Feature Showcase**: Highlights key features and benefits of the app.
- **Pricing Information**: Details on subscription tiers.
- **Download Links**: Direct links to app stores.

## Architecture
(See [Architecture Document](docs/architecture.md) for detailed information)

The application follows a clean architecture approach, separating concerns into presentation, domain, and data layers. Firebase is used as the backend-as-a-service (BaaS) for authentication, Firestore database, and other cloud functions. OpenAI API is integrated for AI-powered features.

## Setup Guide
(See [Setup Guide](docs/setup_guide.md) for detailed instructions)

This section will provide step-by-step instructions on how to set up the development environment, configure Firebase, and run the mobile app, admin panel, and landing website locally.

## Admin Panel
(See [Admin Panel Guide](docs/admin_panel.md) for detailed information)

Instructions on how to deploy and use the Flutter Web Admin Panel.

## Monetization
(See [Monetization Strategy](docs/monetization.md) for detailed information)

This document outlines the monetization strategy, including subscription models and AdMob integration.

## Deployment
(See [Deployment Guide](docs/deployment.md) for detailed instructions)

Instructions for deploying the mobile app to Google Play Store and Apple App Store, the Admin Panel to a web server, and the landing website to a hosting service.

## Maintenance
(See [Maintenance Guide](docs/maintenance.md) for detailed information)

Guidelines for ongoing maintenance, updates, and troubleshooting.

## API Documentation
(See [API Documentation](docs/api_docs.md) for detailed information)

Details on the internal API structure and external API integrations (e.g., OpenAI).

## Contributing
We welcome contributions! Please see our [Contributing Guidelines](CONTRIBUTING.md) for more information.

## License
This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
