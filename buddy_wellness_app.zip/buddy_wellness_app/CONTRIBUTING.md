# Contributing to Buddy Wellness

We welcome contributions to the Buddy Wellness project! By contributing, you help us improve the app for everyone. Please take a moment to review this document to ensure a smooth and effective contribution process.

## How to Contribute

### 1. Reporting Bugs

If you find a bug, please open an issue on our GitHub repository. Before opening a new issue, please:

-   **Search existing issues**: Check if the bug has already been reported.
-   **Provide detailed information**: Include steps to reproduce the bug, expected behavior, actual behavior, screenshots (if applicable), and your environment details (OS, device, app version).

### 2. Suggesting Enhancements

We love new ideas! If you have a suggestion for a new feature or an improvement to an existing one, please open an issue. Describe your idea clearly and explain why you think it would be beneficial.

### 3. Code Contributions

We appreciate code contributions. To contribute code, please follow these steps:

1.  **Fork the Repository**: Fork the `buddy_wellness_app` repository to your GitHub account.
2.  **Clone Your Fork**: Clone your forked repository to your local machine.
    ```bash
    git clone https://github.com/YOUR_USERNAME/buddy_wellness_app.git
    cd buddy_wellness_app
    ```
3.  **Create a New Branch**: Create a new branch for your feature or bug fix. Use a descriptive name (e.g., `feature/add-dark-mode`, `bugfix/login-issue`).
    ```bash
    git checkout -b feature/your-feature-name
    ```
4.  **Make Your Changes**: Implement your changes, ensuring you follow our coding style and best practices.
    -   **Coding Style**: Adhere to the [Dart style guide](https://dart.dev/guides/language/effective-dart).
    -   **Tests**: Write unit, widget, or integration tests for your changes where appropriate.
    -   **Documentation**: Update any relevant documentation (e.g., `README.md`, `docs/`).
5.  **Test Your Changes**: Ensure your changes do not introduce new bugs and that all existing tests pass.
    ```bash
    flutter test
    ```
6.  **Commit Your Changes**: Write clear and concise commit messages.
    ```bash
    git commit -m "feat: Add new feature X" # or "fix: Resolve bug Y"
    ```
7.  **Push to Your Fork**: Push your branch to your forked repository.
    ```bash
    git push origin feature/your-feature-name
    ```
8.  **Open a Pull Request (PR)**: Go to the original `buddy_wellness_app` repository on GitHub and open a new Pull Request from your branch. Provide a clear description of your changes and reference any related issues.

## Code of Conduct

We expect all contributors to adhere to our Code of Conduct. Please be respectful and constructive in all interactions.

## License

By contributing to Buddy Wellness, you agree that your contributions will be licensed under the [MIT License](LICENSE).
