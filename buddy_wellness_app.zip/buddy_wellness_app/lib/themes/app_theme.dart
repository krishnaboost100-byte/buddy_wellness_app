import 'package:flutter/material.dart';

class AppTheme {
  static final Color _lightPrimaryColor = Colors.deepPurple;
  static final Color _lightAccentColor = Colors.deepPurpleAccent;
  static final Color _lightBackgroundColor = Colors.grey[50]!;
  static final Color _lightCardColor = Colors.white;

  static final Color _darkPrimaryColor = Colors.deepPurple[700]!;
  static final Color _darkAccentColor = Colors.deepPurpleAccent[400]!;
  static final Color _darkBackgroundColor = Colors.grey[900]!;
  static final Color _darkCardColor = Colors.grey[850]!;

  static final TextTheme _lightTextTheme = TextTheme(
    displayLarge: TextStyle(fontSize: 96.0, color: Colors.black87, fontFamily: 'Poppins'),
    displayMedium: TextStyle(fontSize: 60.0, color: Colors.black87, fontFamily: 'Poppins'),
    displaySmall: TextStyle(fontSize: 48.0, color: Colors.black87, fontFamily: 'Poppins'),
    headlineLarge: TextStyle(fontSize: 40.0, color: Colors.black87, fontFamily: 'Poppins', fontWeight: FontWeight.bold),
    headlineMedium: TextStyle(fontSize: 34.0, color: Colors.black87, fontFamily: 'Poppins', fontWeight: FontWeight.bold),
    headlineSmall: TextStyle(fontSize: 24.0, color: Colors.black87, fontFamily: 'Poppins', fontWeight: FontWeight.bold),
    titleLarge: TextStyle(fontSize: 20.0, color: Colors.black87, fontFamily: 'Poppins', fontWeight: FontWeight.bold),
    titleMedium: TextStyle(fontSize: 16.0, color: Colors.black87, fontFamily: 'Poppins', fontWeight: FontWeight.w600),
    titleSmall: TextStyle(fontSize: 14.0, color: Colors.black87, fontFamily: 'Poppins', fontWeight: FontWeight.w600),
    bodyLarge: TextStyle(fontSize: 16.0, color: Colors.black87, fontFamily: 'Poppins'),
    bodyMedium: TextStyle(fontSize: 14.0, color: Colors.black87, fontFamily: 'Poppins'),
    bodySmall: TextStyle(fontSize: 12.0, color: Colors.black87, fontFamily: 'Poppins'),
    labelLarge: TextStyle(fontSize: 14.0, color: Colors.white, fontFamily: 'Poppins', fontWeight: FontWeight.bold),
    labelMedium: TextStyle(fontSize: 12.0, color: Colors.white, fontFamily: 'Poppins'),
    labelSmall: TextStyle(fontSize: 10.0, color: Colors.white, fontFamily: 'Poppins'),
  );

  static final TextTheme _darkTextTheme = TextTheme(
    displayLarge: TextStyle(fontSize: 96.0, color: Colors.white70, fontFamily: 'Poppins'),
    displayMedium: TextStyle(fontSize: 60.0, color: Colors.white70, fontFamily: 'Poppins'),
    displaySmall: TextStyle(fontSize: 48.0, color: Colors.white70, fontFamily: 'Poppins'),
    headlineLarge: TextStyle(fontSize: 40.0, color: Colors.white, fontFamily: 'Poppins', fontWeight: FontWeight.bold),
    headlineMedium: TextStyle(fontSize: 34.0, color: Colors.white, fontFamily: 'Poppins', fontWeight: FontWeight.bold),
    headlineSmall: TextStyle(fontSize: 24.0, color: Colors.white, fontFamily: 'Poppins', fontWeight: FontWeight.bold),
    titleLarge: TextStyle(fontSize: 20.0, color: Colors.white, fontFamily: 'Poppins', fontWeight: FontWeight.bold),
    titleMedium: TextStyle(fontSize: 16.0, color: Colors.white, fontFamily: 'Poppins', fontWeight: FontWeight.w600),
    titleSmall: TextStyle(fontSize: 14.0, color: Colors.white, fontFamily: 'Poppins', fontWeight: FontWeight.w600),
    bodyLarge: TextStyle(fontSize: 16.0, color: Colors.white70, fontFamily: 'Poppins'),
    bodyMedium: TextStyle(fontSize: 14.0, color: Colors.white70, fontFamily: 'Poppins'),
    bodySmall: TextStyle(fontSize: 12.0, color: Colors.white70, fontFamily: 'Poppins'),
    labelLarge: TextStyle(fontSize: 14.0, color: Colors.black87, fontFamily: 'Poppins', fontWeight: FontWeight.bold),
    labelMedium: TextStyle(fontSize: 12.0, color: Colors.black87, fontFamily: 'Poppins'),
    labelSmall: TextStyle(fontSize: 10.0, color: Colors.black87, fontFamily: 'Poppins'),
  );

  static ThemeData lightTheme = ThemeData(
    brightness: Brightness.light,
    colorScheme: ColorScheme.fromSeed(
      seedColor: _lightPrimaryColor,
      primary: _lightPrimaryColor,
      secondary: _lightAccentColor,
      background: _lightBackgroundColor,
      surface: _lightCardColor,
      onPrimary: Colors.white,
      onSecondary: Colors.white,
      onBackground: Colors.black87,
      onSurface: Colors.black87,
    ),
    scaffoldBackgroundColor: _lightBackgroundColor,
    appBarTheme: AppBarTheme(
      backgroundColor: _lightPrimaryColor,
      foregroundColor: Colors.white,
      elevation: 0,
      titleTextStyle: _lightTextTheme.headlineSmall?.copyWith(color: Colors.white),
    ),
    cardTheme: CardTheme(
      color: _lightCardColor,
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ),
    textTheme: _lightTextTheme,
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.grey[200],
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide.none,
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: _lightPrimaryColor, width: 2),
      ),
    ),
    buttonTheme: ButtonThemeData(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      buttonColor: _lightAccentColor,
      textTheme: ButtonTextTheme.primary,
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: _lightAccentColor,
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
        textStyle: _lightTextTheme.labelLarge,
      ),
    ),
    floatingActionButtonTheme: FloatingActionButtonThemeData(
      backgroundColor: _lightAccentColor,
      foregroundColor: Colors.white,
    ),
    // Add more theme properties as needed for Material 3
    useMaterial3: true,
  );

  static ThemeData darkTheme = ThemeData(
    brightness: Brightness.dark,
    colorScheme: ColorScheme.fromSeed(
      seedColor: _darkPrimaryColor,
      primary: _darkPrimaryColor,
      secondary: _darkAccentColor,
      background: _darkBackgroundColor,
      surface: _darkCardColor,
      onPrimary: Colors.white,
      onSecondary: Colors.white,
      onBackground: Colors.white70,
      onSurface: Colors.white70,
      brightness: Brightness.dark,
    ),
    scaffoldBackgroundColor: _darkBackgroundColor,
    appBarTheme: AppBarTheme(
      backgroundColor: _darkPrimaryColor,
      foregroundColor: Colors.white,
      elevation: 0,
      titleTextStyle: _darkTextTheme.headlineSmall?.copyWith(color: Colors.white),
    ),
    cardTheme: CardTheme(
      color: _darkCardColor,
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ),
    textTheme: _darkTextTheme,
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.grey[700],
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide.none,
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: _darkPrimaryColor, width: 2),
      ),
    ),
    buttonTheme: ButtonThemeData(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      buttonColor: _darkAccentColor,
      textTheme: ButtonTextTheme.primary,
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: _darkAccentColor,
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
        textStyle: _darkTextTheme.labelLarge,
      ),
    ),
    floatingActionButtonTheme: FloatingActionButtonThemeData(
      backgroundColor: _darkAccentColor,
      foregroundColor: Colors.white,
    ),
    // Add more theme properties as needed for Material 3
    useMaterial3: true,
  );
}
