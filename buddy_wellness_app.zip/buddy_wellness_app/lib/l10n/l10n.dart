import 'package:flutter/widgets.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

export 'package:flutter_gen/gen_l10n/app_localizations.dart';

abstract class L10n {
  static final all = [
    const Locale('en'),
    const Locale('hi'),
    const Locale('ur'),
    const Locale('ar'),
    const Locale('es'),
  ];
}
