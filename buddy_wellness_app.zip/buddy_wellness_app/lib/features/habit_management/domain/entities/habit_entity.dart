import 'package:equatable/equatable.dart';

class HabitEntity extends Equatable {
  final String? id;
  final String userId;
  final String name;
  final String description;
  final String category;
  final String priority;
  final List<Map<String, dynamic>> reminders;
  final Map<String, dynamic> schedule;
  final DateTime startDate;
  final DateTime? endDate;
  final bool isArchived;
  final DateTime createdAt;
  final DateTime updatedAt;

  const HabitEntity({
    this.id,
    required this.userId,
    required this.name,
    required this.description,
    required this.category,
    required this.priority,
    required this.reminders,
    required this.schedule,
    required this.startDate,
    this.endDate,
    this.isArchived = false,
    required this.createdAt,
    required this.updatedAt,
  });

  @override
  List<Object?> get props => [
        id,
        userId,
        name,
        description,
        category,
        priority,
        reminders,
        schedule,
        startDate,
        endDate,
        isArchived,
        createdAt,
        updatedAt,
      ];
}
