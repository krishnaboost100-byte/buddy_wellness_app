import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/usecases/usecase.dart';
import '../entities/habit_entity.dart';
import '../repositories/habit_repository.dart';

class UpdateHabit implements UseCase<HabitEntity, HabitEntity> {
  final HabitRepository repository;

  UpdateHabit(this.repository);

  @override
  Future<Either<Failure, HabitEntity>> call(HabitEntity habit) async {
    return await repository.updateHabit(habit);
  }
}
