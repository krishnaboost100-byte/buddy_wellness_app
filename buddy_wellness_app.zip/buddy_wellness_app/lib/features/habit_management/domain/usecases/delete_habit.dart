import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/usecases/usecase.dart';
import '../repositories/habit_repository.dart';

class DeleteHabit implements UseCase<void, DeleteHabitParams> {
  final HabitRepository repository;

  DeleteHabit(this.repository);

  @override
  Future<Either<Failure, void>> call(DeleteHabitParams params) async {
    return await repository.deleteHabit(params.habitId, params.userId);
  }
}

class DeleteHabitParams extends Equatable {
  final String habitId;
  final String userId;

  const DeleteHabitParams({required this.habitId, required this.userId});

  @override
  List<Object?> get props => [habitId, userId];
}
