import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/usecases/usecase.dart';
import '../entities/habit_entity.dart';
import '../repositories/habit_repository.dart';

class GetHabits implements UseCase<List<HabitEntity>, String> {
  final HabitRepository repository;

  GetHabits(this.repository);

  @override
  Future<Either<Failure, List<HabitEntity>>> call(String userId) async {
    return await repository.getHabits(userId);
  }
}
