import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../entities/habit_entity.dart';

abstract class HabitRepository {
  Future<Either<Failure, List<HabitEntity>>> getHabits(String userId);
  Future<Either<Failure, HabitEntity>> createHabit(HabitEntity habit);
  Future<Either<Failure, HabitEntity>> updateHabit(HabitEntity habit);
  Future<Either<Failure, void>> deleteHabit(String habitId, String userId);
  Future<Either<Failure, void>> logHabitCompletion(String habitId, String userId, DateTime date);
}
