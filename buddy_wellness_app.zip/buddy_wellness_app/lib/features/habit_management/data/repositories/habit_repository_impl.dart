import 'package:dartz/dartz.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/network/network_info.dart';
import '../../domain/entities/habit_entity.dart';
import '../../domain/repositories/habit_repository.dart';
import '../datasources/habit_remote_data_source.dart';
import '../models/habit_model.dart';

class HabitRepositoryImpl implements HabitRepository {
  final HabitRemoteDataSource remoteDataSource;
  final NetworkInfo networkInfo;

  HabitRepositoryImpl({
    required this.remoteDataSource,
    required this.networkInfo,
  });

  @override
  Future<Either<Failure, List<HabitEntity>>> getHabits(String userId) async {
    if (await networkInfo.isConnected) {
      try {
        final habits = await remoteDataSource.getHabits(userId);
        return Right(habits);
      } on FirebaseAuthException catch (e) {
        return Left(AuthFailure(message: e.message ?? 'Firebase Auth Error'));
      } catch (e) {
        return Left(ServerFailure(message: e.toString()));
      }
    } else {
      return const Left(NetworkFailure(message: 'No internet connection'));
    }
  }

  @override
  Future<Either<Failure, HabitEntity>> createHabit(HabitEntity habit) async {
    if (await networkInfo.isConnected) {
      try {
        final habitModel = await remoteDataSource.createHabit(HabitModel.fromEntity(habit));
        return Right(habitModel);
      } on FirebaseAuthException catch (e) {
        return Left(AuthFailure(message: e.message ?? 'Firebase Auth Error'));
      } catch (e) {
        return Left(ServerFailure(message: e.toString()));
      }
    } else {
      return const Left(NetworkFailure(message: 'No internet connection'));
    }
  }

  @override
  Future<Either<Failure, HabitEntity>> updateHabit(HabitEntity habit) async {
    if (await networkInfo.isConnected) {
      try {
        final habitModel = await remoteDataSource.updateHabit(HabitModel.fromEntity(habit));
        return Right(habitModel);
      } on FirebaseAuthException catch (e) {
        return Left(AuthFailure(message: e.message ?? 'Firebase Auth Error'));
      } catch (e) {
        return Left(ServerFailure(message: e.toString()));
      }
    } else {
      return const Left(NetworkFailure(message: 'No internet connection'));
    }
  }

  @override
  Future<Either<Failure, void>> deleteHabit(String habitId, String userId) async {
    if (await networkInfo.isConnected) {
      try {
        await remoteDataSource.deleteHabit(habitId, userId);
        return const Right(null);
      } on FirebaseAuthException catch (e) {
        return Left(AuthFailure(message: e.message ?? 'Firebase Auth Error'));
      } catch (e) {
        return Left(ServerFailure(message: e.toString()));
      }
    } else {
      return const Left(NetworkFailure(message: 'No internet connection'));
    }
  }

  @override
  Future<Either<Failure, void>> logHabitCompletion(String habitId, String userId, DateTime date) async {
    if (await networkInfo.isConnected) {
      try {
        await remoteDataSource.logHabitCompletion(habitId, userId, date);
        return const Right(null);
      } on FirebaseAuthException catch (e) {
        return Left(AuthFailure(message: e.message ?? 'Firebase Auth Error'));
      } catch (e) {
        return Left(ServerFailure(message: e.toString()));
      }
    } else {
      return const Left(NetworkFailure(message: 'No internet connection'));
    }
  }
}
