import 'package:cloud_firestore/cloud_firestore.dart';
import '../../domain/entities/habit_entity.dart';

class HabitModel extends HabitEntity {
  const HabitModel({
    super.id,
    required super.userId,
    required super.name,
    required super.description,
    required super.category,
    required super.priority,
    required super.reminders,
    required super.schedule,
    required super.startDate,
    super.endDate,
    super.isArchived,
    required super.createdAt,
    required super.updatedAt,
  });

  factory HabitModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return HabitModel(
      id: doc.id,
      userId: data['userId'],
      name: data['name'],
      description: data['description'],
      category: data['category'],
      priority: data['priority'],
      reminders: List<Map<String, dynamic>>.from(data['reminders'] ?? []),
      schedule: Map<String, dynamic>.from(data['schedule'] ?? {}),
      startDate: (data['startDate'] as Timestamp).toDate(),
      endDate: (data['endDate'] as Timestamp?)?.toDate(),
      isArchived: data['isArchived'] ?? false,
      createdAt: (data['createdAt'] as Timestamp).toDate(),
      updatedAt: (data['updatedAt'] as Timestamp).toDate(),
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'userId': userId,
      'name': name,
      'description': description,
      'category': category,
      'priority': priority,
      'reminders': reminders,
      'schedule': schedule,
      'startDate': Timestamp.fromDate(startDate),
      'endDate': endDate != null ? Timestamp.fromDate(endDate!) : null,
      'isArchived': isArchived,
      'createdAt': Timestamp.fromDate(createdAt),
      'updatedAt': Timestamp.fromDate(updatedAt),
    };
  }

  factory HabitModel.fromEntity(HabitEntity entity) {
    return HabitModel(
      id: entity.id,
      userId: entity.userId,
      name: entity.name,
      description: entity.description,
      category: entity.category,
      priority: entity.priority,
      reminders: entity.reminders,
      schedule: entity.schedule,
      startDate: entity.startDate,
      endDate: entity.endDate,
      isArchived: entity.isArchived,
      createdAt: entity.createdAt,
      updatedAt: entity.updatedAt,
    );
  }
}
