import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../../../../services/firebase_service.dart';
import '../models/habit_model.dart';

abstract class HabitRemoteDataSource {
  Future<List<HabitModel>> getHabits(String userId);
  Future<HabitModel> createHabit(HabitModel habit);
  Future<HabitModel> updateHabit(HabitModel habit);
  Future<void> deleteHabit(String habitId, String userId);
  Future<void> logHabitCompletion(String habitId, String userId, DateTime date);
}

class HabitRemoteDataSourceImpl implements HabitRemoteDataSource {
  final FirebaseFirestore _firestore;
  final FirebaseAuth _firebaseAuth;

  HabitRemoteDataSourceImpl({
    FirebaseFirestore? firestore,
    FirebaseAuth? firebaseAuth,
  })  : _firestore = firestore ?? FirebaseService.firestore,
        _firebaseAuth = firebaseAuth ?? FirebaseService.auth;

  @override
  Future<List<HabitModel>> getHabits(String userId) async {
    final querySnapshot = await _firestore
        .collection('habits')
        .where('userId', isEqualTo: userId)
        .orderBy('createdAt', descending: true)
        .get();
    return querySnapshot.docs.map((doc) => HabitModel.fromFirestore(doc)).toList();
  }

  @override
  Future<HabitModel> createHabit(HabitModel habit) async {
    final docRef = await _firestore.collection('habits').add(habit.toFirestore());
    return habit.copyWith(id: docRef.id);
  }

  @override
  Future<HabitModel> updateHabit(HabitModel habit) async {
    if (habit.id == null) {
      throw Exception('Habit ID cannot be null for update');
    }
    await _firestore.collection('habits').doc(habit.id).update(habit.toFirestore());
    return habit;
  }

  @override
  Future<void> deleteHabit(String habitId, String userId) async {
    await _firestore.collection('habits').doc(habitId).delete();
    // Also delete related habit logs
    final batch = _firestore.batch();
    final habitLogs = await _firestore
        .collection('habit_logs')
        .where('habitId', isEqualTo: habitId)
        .where('userId', isEqualTo: userId)
        .get();
    for (var doc in habitLogs.docs) {
      batch.delete(doc.reference);
    }
    await batch.commit();
  }

  @override
  Future<void> logHabitCompletion(String habitId, String userId, DateTime date) async {
    await _firestore.collection('habit_logs').add({
      'habitId': habitId,
      'userId': userId,
      'date': Timestamp.fromDate(date),
      'status': 'completed',
      'createdAt': Timestamp.now(),
    });
  }
}
