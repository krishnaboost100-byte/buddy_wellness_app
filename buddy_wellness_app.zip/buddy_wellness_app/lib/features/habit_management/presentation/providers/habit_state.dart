import 'package:equatable/equatable.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/usecases/usecase.dart';
import '../../domain/entities/habit_entity.dart';
import '../../domain/usecases/create_habit.dart';
import '../../domain/usecases/delete_habit.dart';
import '../../domain/usecases/get_habits.dart';
import '../../domain/usecases/update_habit.dart';

enum HabitStatus { initial, loading, loaded, error }

class HabitState extends Equatable {
  final HabitStatus status;
  final List<HabitEntity> habits;
  final Failure? failure;

  const HabitState({
    this.status = HabitStatus.initial,
    this.habits = const [],
    this.failure,
  });

  HabitState copyWith({
    HabitStatus? status,
    List<HabitEntity>? habits,
    Failure? failure,
  }) {
    return HabitState(
      status: status ?? this.status,
      habits: habits ?? this.habits,
      failure: failure ?? this.failure,
    );
  }

  @override
  List<Object?> get props => [status, habits, failure];
}

class HabitNotifier extends StateNotifier<HabitState> {
  final GetHabits _getHabits;
  final CreateHabit _createHabit;
  final UpdateHabit _updateHabit;
  final DeleteHabit _deleteHabit;

  HabitNotifier({
    required GetHabits getHabits,
    required CreateHabit createHabit,
    required UpdateHabit updateHabit,
    required DeleteHabit deleteHabit,
  })  : _getHabits = getHabits,
        _createHabit = createHabit,
        _updateHabit = updateHabit,
        _deleteHabit = deleteHabit,
        super(const HabitState());

  Future<void> fetchHabits(String userId) async {
    state = state.copyWith(status: HabitStatus.loading);
    final result = await _getHabits(userId);
    result.fold(
      (failure) => state = state.copyWith(status: HabitStatus.error, failure: failure),
      (habits) => state = state.copyWith(status: HabitStatus.loaded, habits: habits),
    );
  }

  Future<void> addHabit(HabitEntity habit) async {
    state = state.copyWith(status: HabitStatus.loading);
    final result = await _createHabit(habit);
    result.fold(
      (failure) => state = state.copyWith(status: HabitStatus.error, failure: failure),
      (newHabit) => state = state.copyWith(
        status: HabitStatus.loaded,
        habits: [...state.habits, newHabit],
      ),
    );
  }

  Future<void> editHabit(HabitEntity habit) async {
    state = state.copyWith(status: HabitStatus.loading);
    final result = await _updateHabit(habit);
    result.fold(
      (failure) => state = state.copyWith(status: HabitStatus.error, failure: failure),
      (updatedHabit) => state = state.copyWith(
        status: HabitStatus.loaded,
        habits: state.habits.map((h) => h.id == updatedHabit.id ? updatedHabit : h).toList(),
      ),
    );
  }

  Future<void> removeHabit(String habitId, String userId) async {
    state = state.copyWith(status: HabitStatus.loading);
    final result = await _deleteHabit(DeleteHabitParams(habitId: habitId, userId: userId));
    result.fold(
      (failure) => state = state.copyWith(status: HabitStatus.error, failure: failure),
      (_) => state = state.copyWith(
        status: HabitStatus.loaded,
        habits: state.habits.where((h) => h.id != habitId).toList(),
      ),
    );
  }
}

final habitNotifierProvider = StateNotifierProvider<HabitNotifier, HabitState>((ref) {
  return HabitNotifier(
    getHabits: ref.read(getHabitsProvider),
    createHabit: ref.read(createHabitProvider),
    updateHabit: ref.read(updateHabitProvider),
    deleteHabit: ref.read(deleteHabitProvider),
  );
});


