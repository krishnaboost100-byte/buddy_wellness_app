import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

class HabitListScreen extends ConsumerWidget {
  const HabitListScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Habits'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () {
              // TODO: Navigate to add new habit screen
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Add new habit not yet implemented')),
              );
            },
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: 5, // Placeholder for actual habit count
        itemBuilder: (context, index) {
          return Card(
            margin: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
            child: ListTile(
              leading: Checkbox(
                value: index % 2 == 0, // Just for demonstration
                onChanged: (bool? value) {
                  // TODO: Implement habit completion toggle
                },
              ),
              title: Text('Habit ${index + 1}'),
              subtitle: const Text('Daily at 8:00 AM - Category: Health'),
              trailing: IconButton(
                icon: const Icon(Icons.edit),
                onPressed: () {
                  // TODO: Navigate to edit habit screen
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Edit habit not yet implemented')),
                  );
                },
              ),
              onTap: () {
                // TODO: Navigate to habit details screen
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Habit details not yet implemented')),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
