import 'package:equatable/equatable.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/errors/failures.dart';
import '../../domain/entities/dashboard_entity.dart';
import '../../domain/usecases/get_dashboard_data.dart';

enum DashboardStatus { initial, loading, loaded, error }

class DashboardState extends Equatable {
  final DashboardStatus status;
  final DashboardEntity? dashboardData;
  final Failure? failure;

  const DashboardState({
    this.status = DashboardStatus.initial,
    this.dashboardData,
    this.failure,
  });

  DashboardState copyWith({
    DashboardStatus? status,
    DashboardEntity? dashboardData,
    Failure? failure,
  }) {
    return DashboardState(
      status: status ?? this.status,
      dashboardData: dashboardData ?? this.dashboardData,
      failure: failure ?? this.failure,
    );
  }

  @override
  List<Object?> get props => [status, dashboardData, failure];
}

class DashboardNotifier extends StateNotifier<DashboardState> {
  final GetDashboardData _getDashboardData;

  DashboardNotifier({required GetDashboardData getDashboardData})
      : _getDashboardData = getDashboardData,
        super(const DashboardState());

  Future<void> fetchDashboardData(String userId) async {
    state = state.copyWith(status: DashboardStatus.loading);
    final result = await _getDashboardData(userId);
    result.fold(
      (failure) => state = state.copyWith(status: DashboardStatus.error, failure: failure),
      (data) => state = state.copyWith(status: DashboardStatus.loaded, dashboardData: data),
    );
  }
}

final dashboardNotifierProvider = StateNotifierProvider<DashboardNotifier, DashboardState>((ref) {
  // TODO: Implement dependency injection for use cases
  return DashboardNotifier(
    getDashboardData: ref.read(getDashboardDataProvider),
  );
});


