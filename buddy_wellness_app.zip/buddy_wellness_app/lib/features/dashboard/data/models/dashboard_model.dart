import '../../domain/entities/dashboard_entity.dart';

class DashboardModel extends DashboardEntity {
  const DashboardModel({
    required super.todayHabitsCount,
    required super.completedHabitsCount,
    required super.wellnessScore,
    required super.mood,
    required super.aiSuggestion,
    required super.currentStreak,
    required super.motivationalQuote,
  });

  factory DashboardModel.fromJson(Map<String, dynamic> json) {
    return DashboardModel(
      todayHabitsCount: json["todayHabitsCount"],
      completedHabitsCount: json["completedHabitsCount"],
      wellnessScore: json["wellnessScore"].toDouble(),
      mood: json["mood"],
      aiSuggestion: json["aiSuggestion"],
      currentStreak: json["currentStreak"],
      motivationalQuote: json["motivationalQuote"],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "todayHabitsCount": todayHabitsCount,
      "completedHabitsCount": completedHabitsCount,
      "wellnessScore": wellnessScore,
      "mood": mood,
      "aiSuggestion": aiSuggestion,
      "currentStreak": currentStreak,
      "motivationalQuote": motivationalQuote,
    };
  }

  factory DashboardModel.fromEntity(DashboardEntity entity) {
    return DashboardModel(
      todayHabitsCount: entity.todayHabitsCount,
      completedHabitsCount: entity.completedHabitsCount,
      wellnessScore: entity.wellnessScore,
      mood: entity.mood,
      aiSuggestion: entity.aiSuggestion,
      currentStreak: entity.currentStreak,
      motivationalQuote: entity.motivationalQuote,
    );
  }
}
