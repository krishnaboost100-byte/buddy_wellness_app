import 'package:equatable/equatable.dart';

class DashboardEntity extends Equatable {
  final int todayHabitsCount;
  final int completedHabitsCount;
  final double wellnessScore;
  final String mood;
  final String aiSuggestion;
  final int currentStreak;
  final String motivationalQuote;

  const DashboardEntity({
    required this.todayHabitsCount,
    required this.completedHabitsCount,
    required this.wellnessScore,
    required this.mood,
    required this.aiSuggestion,
    required this.currentStreak,
    required this.motivationalQuote,
  });

  @override
  List<Object?> get props => [
        todayHabitsCount,
        completedHabitsCount,
        wellnessScore,
        mood,
        aiSuggestion,
        currentStreak,
        motivationalQuote,
      ];
}
