import 'package:equatable/equatable.dart';

class SettingsEntity extends Equatable {
  final String userId;
  final bool darkMode;
  final String language;
  final Map<String, bool> notificationPreferences;
  final Map<String, bool> privacyControls;

  const SettingsEntity({
    required this.userId,
    required this.darkMode,
    required this.language,
    required this.notificationPreferences,
    required this.privacyControls,
  });

  @override
  List<Object?> get props => [
        userId,
        darkMode,
        language,
        notificationPreferences,
        privacyControls,
      ];
}
