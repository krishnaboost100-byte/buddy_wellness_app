import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/usecases/usecase.dart';
import '../entities/settings_entity.dart';
import '../repositories/settings_repository.dart';

class GetSettings implements UseCase<SettingsEntity, String> {
  final SettingsRepository repository;

  GetSettings(this.repository);

  @override
  Future<Either<Failure, SettingsEntity>> call(String userId) async {
    return await repository.getSettings(userId);
  }
}
