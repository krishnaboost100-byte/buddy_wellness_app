import 'package:cloud_firestore/cloud_firestore.dart';
import '../../domain/entities/settings_entity.dart';

class SettingsModel extends SettingsEntity {
  const SettingsModel({
    required super.userId,
    required super.darkMode,
    required super.language,
    required super.notificationPreferences,
    required super.privacyControls,
  });

  factory SettingsModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return SettingsModel(
      userId: doc.id,
      darkMode: data['darkMode'] ?? false,
      language: data['language'] ?? 'en',
      notificationPreferences: Map<String, bool>.from(data['notificationPreferences'] ?? {}),
      privacyControls: Map<String, bool>.from(data['privacyControls'] ?? {}),
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'darkMode': darkMode,
      'language': language,
      'notificationPreferences': notificationPreferences,
      'privacyControls': privacyControls,
    };
  }

  factory SettingsModel.fromEntity(SettingsEntity entity) {
    return SettingsModel(
      userId: entity.userId,
      darkMode: entity.darkMode,
      language: entity.language,
      notificationPreferences: entity.notificationPreferences,
      privacyControls: entity.privacyControls,
    );
  }
}
