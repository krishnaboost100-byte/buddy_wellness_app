import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../../../../services/firebase_service.dart';
import '../models/settings_model.dart';

abstract class SettingsRemoteDataSource {
  Future<SettingsModel> getSettings(String userId);
  Future<void> updateSettings(SettingsModel settings);
}

class SettingsRemoteDataSourceImpl implements SettingsRemoteDataSource {
  final FirebaseFirestore _firestore;
  final FirebaseAuth _firebaseAuth;

  SettingsRemoteDataSourceImpl({
    FirebaseFirestore? firestore,
    FirebaseAuth? firebaseAuth,
  })  : _firestore = firestore ?? FirebaseService.firestore,
        _firebaseAuth = firebaseAuth ?? FirebaseService.auth;

  @override
  Future<SettingsModel> getSettings(String userId) async {
    final doc = await _firestore.collection('app_settings').doc(userId).get();
    if (!doc.exists) {
      // Return default settings if not found
      return SettingsModel(
        userId: userId,
        darkMode: false,
        language: 'en',
        notificationPreferences: {},
        privacyControls: {},
      );
    }
    return SettingsModel.fromFirestore(doc);
  }

  @override
  Future<void> updateSettings(SettingsModel settings) async {
    await _firestore.collection('app_settings').doc(settings.userId).set(settings.toFirestore(), SetOptions(merge: true));
  }
}
