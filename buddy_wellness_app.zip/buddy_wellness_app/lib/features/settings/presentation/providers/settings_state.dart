import 'package:equatable/equatable.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/errors/failures.dart';
import '../../domain/entities/settings_entity.dart';
import '../../domain/usecases/get_settings.dart';
import '../../domain/usecases/update_settings.dart';

enum SettingsStatus { initial, loading, loaded, error }

class SettingsState extends Equatable {
  final SettingsStatus status;
  final SettingsEntity? settings;
  final Failure? failure;

  const SettingsState({
    this.status = SettingsStatus.initial,
    this.settings,
    this.failure,
  });

  SettingsState copyWith({
    SettingsStatus? status,
    SettingsEntity? settings,
    Failure? failure,
  }) {
    return SettingsState(
      status: status ?? this.status,
      settings: settings ?? this.settings,
      failure: failure ?? this.failure,
    );
  }

  @override
  List<Object?> get props => [status, settings, failure];
}

class SettingsNotifier extends StateNotifier<SettingsState> {
  final GetSettings _getSettings;
  final UpdateSettings _updateSettings;

  SettingsNotifier({
    required GetSettings getSettings,
    required UpdateSettings updateSettings,
  })  : _getSettings = getSettings,
        _updateSettings = updateSettings,
        super(const SettingsState());

  Future<void> fetchSettings(String userId) async {
    state = state.copyWith(status: SettingsStatus.loading);
    final result = await _getSettings(userId);
    result.fold(
      (failure) => state = state.copyWith(status: SettingsStatus.error, failure: failure),
      (settings) => state = state.copyWith(status: SettingsStatus.loaded, settings: settings),
    );
  }

  Future<void> updateSettings(SettingsEntity settings) async {
    state = state.copyWith(status: SettingsStatus.loading);
    final result = await _updateSettings(settings);
    result.fold(
      (failure) => state = state.copyWith(status: SettingsStatus.error, failure: failure),
      (_) => state = state.copyWith(status: SettingsStatus.loaded, settings: settings),
    );
  }
}

final settingsNotifierProvider = StateNotifierProvider<SettingsNotifier, SettingsState>((ref) {
  return SettingsNotifier(
    getSettings: ref.read(getSettingsProvider),
    updateSettings: ref.read(updateSettingsProvider),
  );
});


