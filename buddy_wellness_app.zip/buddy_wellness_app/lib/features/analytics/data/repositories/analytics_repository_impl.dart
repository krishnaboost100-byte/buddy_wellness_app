import 'package:dartz/dartz.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/network/network_info.dart';
import '../../domain/entities/analytics_entity.dart';
import '../../domain/repositories/analytics_repository.dart';
import '../datasources/analytics_remote_data_source.dart';
import '../models/analytics_model.dart';

class AnalyticsRepositoryImpl implements AnalyticsRepository {
  final AnalyticsRemoteDataSource remoteDataSource;
  final NetworkInfo networkInfo;

  AnalyticsRepositoryImpl({
    required this.remoteDataSource,
    required this.networkInfo,
  });

  @override
  Future<Either<Failure, List<AnalyticsEntity>>> getAnalyticsData(String userId) async {
    if (await networkInfo.isConnected) {
      try {
        final analytics = await remoteDataSource.getAnalyticsData(userId);
        return Right(analytics);
      } on FirebaseAuthException catch (e) {
        return Left(AuthFailure(message: e.message ?? 'Firebase Auth Error'));
      } catch (e) {
        return Left(ServerFailure(message: e.toString()));
      }
    } else {
      return const Left(NetworkFailure(message: 'No internet connection'));
    }
  }

  @override
  Future<Either<Failure, void>> saveAnalyticsData(AnalyticsEntity analytics) async {
    if (await networkInfo.isConnected) {
      try {
        await remoteDataSource.saveAnalyticsData(AnalyticsModel.fromEntity(analytics));
        return const Right(null);
      } on FirebaseAuthException catch (e) {
        return Left(AuthFailure(message: e.message ?? 'Firebase Auth Error'));
      } catch (e) {
        return Left(ServerFailure(message: e.toString()));
      }
    } else {
      return const Left(NetworkFailure(message: 'No internet connection'));
    }
  }
}
