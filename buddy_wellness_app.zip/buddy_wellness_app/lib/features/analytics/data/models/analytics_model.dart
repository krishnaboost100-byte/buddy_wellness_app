import 'package:cloud_firestore/cloud_firestore.dart';
import '../../domain/entities/analytics_entity.dart';

class AnalyticsModel extends AnalyticsEntity {
  const AnalyticsModel({
    required super.userId,
    required super.date,
    required super.wellnessScore,
    required super.mood,
    required super.habitCompletionRates,
    required super.productivityScore,
    required super.insights,
  });

  factory AnalyticsModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return AnalyticsModel(
      userId: data['userId'],
      date: (data['date'] as Timestamp).toDate(),
      wellnessScore: data['wellnessScore'],
      mood: data['mood'],
      habitCompletionRates: Map<String, double>.from(data['habitCompletionRates'] ?? {}),
      productivityScore: data['productivityScore'],
      insights: List<String>.from(data['insights'] ?? []),
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'userId': userId,
      'date': Timestamp.fromDate(date),
      'wellnessScore': wellnessScore,
      'mood': mood,
      'habitCompletionRates': habitCompletionRates,
      'productivityScore': productivityScore,
      'insights': insights,
    };
  }

  factory AnalyticsModel.fromEntity(AnalyticsEntity entity) {
    return AnalyticsModel(
      userId: entity.userId,
      date: entity.date,
      wellnessScore: entity.wellnessScore,
      mood: entity.mood,
      habitCompletionRates: entity.habitCompletionRates,
      productivityScore: entity.productivityScore,
      insights: entity.insights,
    );
  }
}
