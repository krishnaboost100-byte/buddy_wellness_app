import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../../../../services/firebase_service.dart';
import '../models/analytics_model.dart';

abstract class AnalyticsRemoteDataSource {
  Future<List<AnalyticsModel>> getAnalyticsData(String userId);
  Future<void> saveAnalyticsData(AnalyticsModel analytics);
}

class AnalyticsRemoteDataSourceImpl implements AnalyticsRemoteDataSource {
  final FirebaseFirestore _firestore;
  final FirebaseAuth _firebaseAuth;

  AnalyticsRemoteDataSourceImpl({
    FirebaseFirestore? firestore,
    FirebaseAuth? firebaseAuth,
  })  : _firestore = firestore ?? FirebaseService.firestore,
        _firebaseAuth = firebaseAuth ?? FirebaseService.auth;

  @override
  Future<List<AnalyticsModel>> getAnalyticsData(String userId) async {
    final querySnapshot = await _firestore
        .collection('analytics')
        .where('userId', isEqualTo: userId)
        .orderBy('date', descending: true)
        .get();
    return querySnapshot.docs.map((doc) => AnalyticsModel.fromFirestore(doc)).toList();
  }

  @override
  Future<void> saveAnalyticsData(AnalyticsModel analytics) async {
    await _firestore.collection('analytics').add(analytics.toFirestore());
  }
}
