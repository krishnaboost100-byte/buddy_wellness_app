import 'package:equatable/equatable.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/errors/failures.dart';
import '../../domain/entities/analytics_entity.dart';
import '../../domain/usecases/get_analytics_data.dart';

enum AnalyticsStatus { initial, loading, loaded, error }

class AnalyticsState extends Equatable {
  final AnalyticsStatus status;
  final List<AnalyticsEntity> analyticsData;
  final Failure? failure;

  const AnalyticsState({
    this.status = AnalyticsStatus.initial,
    this.analyticsData = const [],
    this.failure,
  });

  AnalyticsState copyWith({
    AnalyticsStatus? status,
    List<AnalyticsEntity>? analyticsData,
    Failure? failure,
  }) {
    return AnalyticsState(
      status: status ?? this.status,
      analyticsData: analyticsData ?? this.analyticsData,
      failure: failure ?? this.failure,
    );
  }

  @override
  List<Object?> get props => [status, analyticsData, failure];
}

class AnalyticsNotifier extends StateNotifier<AnalyticsState> {
  final GetAnalyticsData _getAnalyticsData;

  AnalyticsNotifier({required GetAnalyticsData getAnalyticsData})
      : _getAnalyticsData = getAnalyticsData,
        super(const AnalyticsState());

  Future<void> fetchAnalyticsData(String userId) async {
    state = state.copyWith(status: AnalyticsStatus.loading);
    final result = await _getAnalyticsData(userId);
    result.fold(
      (failure) => state = state.copyWith(status: AnalyticsStatus.error, failure: failure),
      (data) => state = state.copyWith(status: AnalyticsStatus.loaded, analyticsData: data),
    );
  }
}

final analyticsNotifierProvider = StateNotifierProvider<AnalyticsNotifier, AnalyticsState>((ref) {
  // TODO: Implement dependency injection for use cases
  return AnalyticsNotifier(
    getAnalyticsData: ref.read(getAnalyticsDataProvider),
  );
});


