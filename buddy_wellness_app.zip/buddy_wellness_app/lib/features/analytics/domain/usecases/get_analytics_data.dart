import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/usecases/usecase.dart';
import '../entities/analytics_entity.dart';
import '../repositories/analytics_repository.dart';

class GetAnalyticsData implements UseCase<List<AnalyticsEntity>, String> {
  final AnalyticsRepository repository;

  GetAnalyticsData(this.repository);

  @override
  Future<Either<Failure, List<AnalyticsEntity>>> call(String userId) async {
    return await repository.getAnalyticsData(userId);
  }
}
