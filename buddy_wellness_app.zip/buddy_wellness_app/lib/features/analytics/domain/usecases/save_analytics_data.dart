import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/usecases/usecase.dart';
import '../entities/analytics_entity.dart';
import '../repositories/analytics_repository.dart';

class SaveAnalyticsData implements UseCase<void, AnalyticsEntity> {
  final AnalyticsRepository repository;

  SaveAnalyticsData(this.repository);

  @override
  Future<Either<Failure, void>> call(AnalyticsEntity analytics) async {
    return await repository.saveAnalyticsData(analytics);
  }
}
