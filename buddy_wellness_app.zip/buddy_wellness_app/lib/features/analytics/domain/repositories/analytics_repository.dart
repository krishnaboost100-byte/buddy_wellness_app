import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../entities/analytics_entity.dart';

abstract class AnalyticsRepository {
  Future<Either<Failure, List<AnalyticsEntity>>> getAnalyticsData(String userId);
  Future<Either<Failure, void>> saveAnalyticsData(AnalyticsEntity analytics);
}
