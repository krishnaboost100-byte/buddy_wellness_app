import 'package:equatable/equatable.dart';

class AnalyticsEntity extends Equatable {
  final String userId;
  final DateTime date;
  final int wellnessScore;
  final String mood;
  final Map<String, double> habitCompletionRates;
  final int productivityScore;
  final List<String> insights;

  const AnalyticsEntity({
    required this.userId,
    required this.date,
    required this.wellnessScore,
    required this.mood,
    required this.habitCompletionRates,
    required this.productivityScore,
    required this.insights,
  });

  @override
  List<Object?> get props => [
        userId,
        date,
        wellnessScore,
        mood,
        habitCompletionRates,
        productivityScore,
        insights,
      ];
}
