import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../../../../services/firebase_service.dart';
import '../models/streak_model.dart';

abstract class StreakRemoteDataSource {
  Future<List<StreakModel>> getStreaks(String userId);
  Future<StreakModel> getStreakById(String streakId);
  Future<StreakModel> createOrUpdateStreak(StreakModel streak);
  Future<void> deleteStreak(String streakId);
}

class StreakRemoteDataSourceImpl implements StreakRemoteDataSource {
  final FirebaseFirestore _firestore;
  final FirebaseAuth _firebaseAuth;

  StreakRemoteDataSourceImpl({
    FirebaseFirestore? firestore,
    FirebaseAuth? firebaseAuth,
  })  : _firestore = firestore ?? FirebaseService.firestore,
        _firebaseAuth = firebaseAuth ?? FirebaseService.auth;

  @override
  Future<List<StreakModel>> getStreaks(String userId) async {
    final querySnapshot = await _firestore
        .collection('streaks')
        .where('userId', isEqualTo: userId)
        .orderBy('updatedAt', descending: true)
        .get();
    return querySnapshot.docs.map((doc) => StreakModel.fromFirestore(doc)).toList();
  }

  @override
  Future<StreakModel> getStreakById(String streakId) async {
    final doc = await _firestore.collection('streaks').doc(streakId).get();
    if (!doc.exists) {
      throw Exception('Streak not found');
    }
    return StreakModel.fromFirestore(doc);
  }

  @override
  Future<StreakModel> createOrUpdateStreak(StreakModel streak) async {
    if (streak.id == null) {
      final docRef = await _firestore.collection('streaks').add(streak.toFirestore());
      return streak.copyWith(id: docRef.id);
    } else {
      await _firestore.collection('streaks').doc(streak.id).set(streak.toFirestore(), SetOptions(merge: true));
      return streak;
    }
  }

  @override
  Future<void> deleteStreak(String streakId) async {
    await _firestore.collection('streaks').doc(streakId).delete();
  }
}
