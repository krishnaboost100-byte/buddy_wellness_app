import 'package:cloud_firestore/cloud_firestore.dart';
import '../../domain/entities/streak_entity.dart';

class StreakModel extends StreakEntity {
  const StreakModel({
    super.id,
    required super.userId,
    super.habitId,
    required super.type,
    required super.currentStreak,
    required super.longestStreak,
    required super.lastCompletionDate,
    required super.updatedAt,
  });

  factory StreakModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return StreakModel(
      id: doc.id,
      userId: data['userId'],
      habitId: data['habitId'],
      type: data['type'],
      currentStreak: data['currentStreak'],
      longestStreak: data['longestStreak'],
      lastCompletionDate: (data['lastCompletionDate'] as Timestamp).toDate(),
      updatedAt: (data['updatedAt'] as Timestamp).toDate(),
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'userId': userId,
      'habitId': habitId,
      'type': type,
      'currentStreak': currentStreak,
      'longestStreak': longestStreak,
      'lastCompletionDate': Timestamp.fromDate(lastCompletionDate),
      'updatedAt': Timestamp.fromDate(updatedAt),
    };
  }

  factory StreakModel.fromEntity(StreakEntity entity) {
    return StreakModel(
      id: entity.id,
      userId: entity.userId,
      habitId: entity.habitId,
      type: entity.type,
      currentStreak: entity.currentStreak,
      longestStreak: entity.longestStreak,
      lastCompletionDate: entity.lastCompletionDate,
      updatedAt: entity.updatedAt,
    );
  }
}
