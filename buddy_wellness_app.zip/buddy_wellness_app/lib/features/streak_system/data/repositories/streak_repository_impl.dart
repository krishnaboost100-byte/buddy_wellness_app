import 'package:dartz/dartz.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/network/network_info.dart';
import '../../domain/entities/streak_entity.dart';
import '../../domain/repositories/streak_repository.dart';
import '../datasources/streak_remote_data_source.dart';
import '../models/streak_model.dart';

class StreakRepositoryImpl implements StreakRepository {
  final StreakRemoteDataSource remoteDataSource;
  final NetworkInfo networkInfo;

  StreakRepositoryImpl({
    required this.remoteDataSource,
    required this.networkInfo,
  });

  @override
  Future<Either<Failure, List<StreakEntity>>> getStreaks(String userId) async {
    if (await networkInfo.isConnected) {
      try {
        final streaks = await remoteDataSource.getStreaks(userId);
        return Right(streaks);
      } on FirebaseAuthException catch (e) {
        return Left(AuthFailure(message: e.message ?? 'Firebase Auth Error'));
      } catch (e) {
        return Left(ServerFailure(message: e.toString()));
      }
    } else {
      return const Left(NetworkFailure(message: 'No internet connection'));
    }
  }

  @override
  Future<Either<Failure, StreakEntity>> getStreakById(String streakId) async {
    if (await networkInfo.isConnected) {
      try {
        final streak = await remoteDataSource.getStreakById(streakId);
        return Right(streak);
      } on FirebaseAuthException catch (e) {
        return Left(AuthFailure(message: e.message ?? 'Firebase Auth Error'));
      } catch (e) {
        return Left(ServerFailure(message: e.toString()));
      }
    } else {
      return const Left(NetworkFailure(message: 'No internet connection'));
    }
  }

  @override
  Future<Either<Failure, StreakEntity>> createOrUpdateStreak(StreakEntity streak) async {
    if (await networkInfo.isConnected) {
      try {
        final streakModel = await remoteDataSource.createOrUpdateStreak(StreakModel.fromEntity(streak));
        return Right(streakModel);
      } on FirebaseAuthException catch (e) {
        return Left(AuthFailure(message: e.message ?? 'Firebase Auth Error'));
      } catch (e) {
        return Left(ServerFailure(message: e.toString()));
      }
    } else {
      return const Left(NetworkFailure(message: 'No internet connection'));
    }
  }

  @override
  Future<Either<Failure, void>> deleteStreak(String streakId) async {
    if (await networkInfo.isConnected) {
      try {
        await remoteDataSource.deleteStreak(streakId);
        return const Right(null);
      } on FirebaseAuthException catch (e) {
        return Left(AuthFailure(message: e.message ?? 'Firebase Auth Error'));
      } catch (e) {
        return Left(ServerFailure(message: e.toString()));
      }
    } else {
      return const Left(NetworkFailure(message: 'No internet connection'));
    }
  }
}
