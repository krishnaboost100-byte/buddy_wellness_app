import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../entities/streak_entity.dart';

abstract class StreakRepository {
  Future<Either<Failure, List<StreakEntity>>> getStreaks(String userId);
  Future<Either<Failure, StreakEntity>> getStreakById(String streakId);
  Future<Either<Failure, StreakEntity>> createOrUpdateStreak(StreakEntity streak);
  Future<Either<Failure, void>> deleteStreak(String streakId);
}
