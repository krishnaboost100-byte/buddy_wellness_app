import 'package:equatable/equatable.dart';

class StreakEntity extends Equatable {
  final String? id;
  final String userId;
  final String? habitId; // Optional, for habit-specific streaks
  final String type; // e.g., 'daily', 'weekly', 'overall'
  final int currentStreak;
  final int longestStreak;
  final DateTime lastCompletionDate;
  final DateTime updatedAt;

  const StreakEntity({
    this.id,
    required this.userId,
    this.habitId,
    required this.type,
    required this.currentStreak,
    required this.longestStreak,
    required this.lastCompletionDate,
    required this.updatedAt,
  });

  @override
  List<Object?> get props => [
        id,
        userId,
        habitId,
        type,
        currentStreak,
        longestStreak,
        lastCompletionDate,
        updatedAt,
      ];
}
