import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/usecases/usecase.dart';
import '../entities/streak_entity.dart';
import '../repositories/streak_repository.dart';

class CreateOrUpdateStreak implements UseCase<StreakEntity, StreakEntity> {
  final StreakRepository repository;

  CreateOrUpdateStreak(this.repository);

  @override
  Future<Either<Failure, StreakEntity>> call(StreakEntity streak) async {
    return await repository.createOrUpdateStreak(streak);
  }
}
