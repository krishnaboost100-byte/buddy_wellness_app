import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/usecases/usecase.dart';
import '../entities/streak_entity.dart';
import '../repositories/streak_repository.dart';

class GetStreaks implements UseCase<List<StreakEntity>, String> {
  final StreakRepository repository;

  GetStreaks(this.repository);

  @override
  Future<Either<Failure, List<StreakEntity>>> call(String userId) async {
    return await repository.getStreaks(userId);
  }
}
