import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/usecases/usecase.dart';
import '../entities/streak_entity.dart';
import '../repositories/streak_repository.dart';

class GetStreakById implements UseCase<StreakEntity, String> {
  final StreakRepository repository;

  GetStreakById(this.repository);

  @override
  Future<Either<Failure, StreakEntity>> call(String streakId) async {
    return await repository.getStreakById(streakId);
  }
}
