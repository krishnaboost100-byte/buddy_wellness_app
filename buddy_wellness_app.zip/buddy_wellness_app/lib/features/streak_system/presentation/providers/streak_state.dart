import 'package:equatable/equatable.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/errors/failures.dart';
import '../../domain/entities/streak_entity.dart';
import '../../domain/usecases/create_or_update_streak.dart';
import '../../domain/usecases/get_streaks.dart';

enum StreakStatus { initial, loading, loaded, error }

class StreakState extends Equatable {
  final StreakStatus status;
  final List<StreakEntity> streaks;
  final Failure? failure;

  const StreakState({
    this.status = StreakStatus.initial,
    this.streaks = const [],
    this.failure,
  });

  StreakState copyWith({
    StreakStatus? status,
    List<StreakEntity>? streaks,
    Failure? failure,
  }) {
    return StreakState(
      status: status ?? this.status,
      streaks: streaks ?? this.streaks,
      failure: failure ?? this.failure,
    );
  }

  @override
  List<Object?> get props => [status, streaks, failure];
}

class StreakNotifier extends StateNotifier<StreakState> {
  final GetStreaks _getStreaks;
  final CreateOrUpdateStreak _createOrUpdateStreak;

  StreakNotifier({
    required GetStreaks getStreaks,
    required CreateOrUpdateStreak createOrUpdateStreak,
  })  : _getStreaks = getStreaks,
        _createOrUpdateStreak = createOrUpdateStreak,
        super(const StreakState());

  Future<void> fetchStreaks(String userId) async {
    state = state.copyWith(status: StreakStatus.loading);
    final result = await _getStreaks(userId);
    result.fold(
      (failure) => state = state.copyWith(status: StreakStatus.error, failure: failure),
      (streaks) => state = state.copyWith(status: StreakStatus.loaded, streaks: streaks),
    );
  }

  Future<void> createOrUpdate(StreakEntity streak) async {
    state = state.copyWith(status: StreakStatus.loading);
    final result = await _createOrUpdateStreak(streak);
    result.fold(
      (failure) => state = state.copyWith(status: StreakStatus.error, failure: failure),
      (newStreak) {
        final updatedStreaks = List<StreakEntity>.from(state.streaks);
        final index = updatedStreaks.indexWhere((s) => s.id == newStreak.id);
        if (index != -1) {
          updatedStreaks[index] = newStreak;
        } else {
          updatedStreaks.add(newStreak);
        }
        state = state.copyWith(status: StreakStatus.loaded, streaks: updatedStreaks);
      },
    );
  }
}

final streakNotifierProvider = StateNotifierProvider<StreakNotifier, StreakState>((ref) {
  return StreakNotifier(
    getStreaks: ref.read(getStreaksProvider),
    createOrUpdateStreak: ref.read(createOrUpdateStreakProvider),
  );
});


