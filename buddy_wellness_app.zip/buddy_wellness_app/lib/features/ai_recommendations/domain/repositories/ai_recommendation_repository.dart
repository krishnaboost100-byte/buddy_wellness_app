import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../entities/ai_recommendation_entity.dart';

abstract class AIRecommendationRepository {
  Future<Either<Failure, List<AIRecommendationEntity>>> getAIRecommendations(String userId);
  Future<Either<Failure, AIRecommendationEntity>> generateAIRecommendation(String userId, String prompt);
  Future<Either<Failure, void>> markRecommendationAsRead(String recommendationId, String userId);
}
