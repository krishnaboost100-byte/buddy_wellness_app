import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/usecases/usecase.dart';
import '../entities/ai_recommendation_entity.dart';
import '../repositories/ai_recommendation_repository.dart';

class GenerateAIRecommendation implements UseCase<AIRecommendationEntity, GenerateAIRecommendationParams> {
  final AIRecommendationRepository repository;

  GenerateAIRecommendation(this.repository);

  @override
  Future<Either<Failure, AIRecommendationEntity>> call(GenerateAIRecommendationParams params) async {
    return await repository.generateAIRecommendation(params.userId, params.prompt);
  }
}

class GenerateAIRecommendationParams extends Equatable {
  final String userId;
  final String prompt;

  const GenerateAIRecommendationParams({required this.userId, required this.prompt});

  @override
  List<Object?> get props => [userId, prompt];
}
