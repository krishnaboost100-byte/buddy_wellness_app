import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/usecases/usecase.dart';
import '../entities/ai_recommendation_entity.dart';
import '../repositories/ai_recommendation_repository.dart';

class GetAIRecommendations implements UseCase<List<AIRecommendationEntity>, String> {
  final AIRecommendationRepository repository;

  GetAIRecommendations(this.repository);

  @override
  Future<Either<Failure, List<AIRecommendationEntity>>> call(String userId) async {
    return await repository.getAIRecommendations(userId);
  }
}
