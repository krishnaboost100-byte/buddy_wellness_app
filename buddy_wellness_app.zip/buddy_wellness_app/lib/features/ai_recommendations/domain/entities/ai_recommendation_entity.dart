import 'package:equatable/equatable.dart';

class AIRecommendationEntity extends Equatable {
  final String id;
  final String userId;
  final String recommendationText;
  final String category;
  final DateTime createdAt;
  final bool isRead;

  const AIRecommendationEntity({
    required this.id,
    required this.userId,
    required this.recommendationText,
    required this.category,
    required this.createdAt,
    this.isRead = false,
  });

  @override
  List<Object?> get props => [
        id,
        userId,
        recommendationText,
        category,
        createdAt,
        isRead,
      ];
}
