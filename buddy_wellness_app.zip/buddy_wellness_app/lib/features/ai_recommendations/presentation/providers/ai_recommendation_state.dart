import 'package:equatable/equatable.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/errors/failures.dart';
import '../../domain/entities/ai_recommendation_entity.dart';
import '../../domain/usecases/generate_ai_recommendation.dart';
import '../../domain/usecases/get_ai_recommendations.dart';

enum AIRecommendationStatus { initial, loading, loaded, error }

class AIRecommendationState extends Equatable {
  final AIRecommendationStatus status;
  final List<AIRecommendationEntity> recommendations;
  final Failure? failure;

  const AIRecommendationState({
    this.status = AIRecommendationStatus.initial,
    this.recommendations = const [],
    this.failure,
  });

  AIRecommendationState copyWith({
    AIRecommendationStatus? status,
    List<AIRecommendationEntity>? recommendations,
    Failure? failure,
  }) {
    return AIRecommendationState(
      status: status ?? this.status,
      recommendations: recommendations ?? this.recommendations,
      failure: failure ?? this.failure,
    );
  }

  @override
  List<Object?> get props => [status, recommendations, failure];
}

class AIRecommendationNotifier extends StateNotifier<AIRecommendationState> {
  final GetAIRecommendations _getAIRecommendations;
  final GenerateAIRecommendation _generateAIRecommendation;

  AIRecommendationNotifier({
    required GetAIRecommendations getAIRecommendations,
    required GenerateAIRecommendation generateAIRecommendation,
  })  : _getAIRecommendations = getAIRecommendations,
        _generateAIRecommendation = generateAIRecommendation,
        super(const AIRecommendationState());

  Future<void> fetchAIRecommendations(String userId) async {
    state = state.copyWith(status: AIRecommendationStatus.loading);
    final result = await _getAIRecommendations(userId);
    result.fold(
      (failure) => state = state.copyWith(status: AIRecommendationStatus.error, failure: failure),
      (recommendations) => state = state.copyWith(status: AIRecommendationStatus.loaded, recommendations: recommendations),
    );
  }

  Future<void> generateRecommendation(String userId, String prompt) async {
    state = state.copyWith(status: AIRecommendationStatus.loading);
    final result = await _generateAIRecommendation(GenerateAIRecommendationParams(userId: userId, prompt: prompt));
    result.fold(
      (failure) => state = state.copyWith(status: AIRecommendationStatus.error, failure: failure),
      (newRecommendation) => state = state.copyWith(
        status: AIRecommendationStatus.loaded,
        recommendations: [newRecommendation, ...state.recommendations],
      ),
    );
  }
}

final aiRecommendationNotifierProvider = StateNotifierProvider<AIRecommendationNotifier, AIRecommendationState>((ref) {
  return AIRecommendationNotifier(
    getAIRecommendations: ref.read(getAIRecommendationsProvider),
    generateAIRecommendation: ref.read(generateAIRecommendationProvider),
  );
});


