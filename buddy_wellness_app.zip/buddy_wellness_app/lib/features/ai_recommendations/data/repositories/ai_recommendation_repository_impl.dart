import 'package:dartz/dartz.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/network/network_info.dart';
import '../../domain/entities/ai_recommendation_entity.dart';
import '../../domain/repositories/ai_recommendation_repository.dart';
import '../datasources/ai_recommendation_remote_data_source.dart';
import '../models/ai_recommendation_model.dart';

class AIRecommendationRepositoryImpl implements AIRecommendationRepository {
  final AIRecommendationRemoteDataSource remoteDataSource;
  final NetworkInfo networkInfo;

  AIRecommendationRepositoryImpl({
    required this.remoteDataSource,
    required this.networkInfo,
  });

  @override
  Future<Either<Failure, List<AIRecommendationEntity>>> getAIRecommendations(String userId) async {
    if (await networkInfo.isConnected) {
      try {
        final recommendations = await remoteDataSource.getAIRecommendations(userId);
        return Right(recommendations);
      } on FirebaseAuthException catch (e) {
        return Left(AuthFailure(message: e.message ?? 'Firebase Auth Error'));
      } catch (e) {
        return Left(ServerFailure(message: e.toString()));
      }
    } else {
      return const Left(NetworkFailure(message: 'No internet connection'));
    }
  }

  @override
  Future<Either<Failure, AIRecommendationEntity>> generateAIRecommendation(String userId, String prompt) async {
    if (await networkInfo.isConnected) {
      try {
        final recommendation = await remoteDataSource.generateAIRecommendation(userId, prompt);
        return Right(recommendation);
      } on FirebaseAuthException catch (e) {
        return Left(AuthFailure(message: e.message ?? 'Firebase Auth Error'));
      } catch (e) {
        return Left(ServerFailure(message: e.toString()));
      }
    } else {
      return const Left(NetworkFailure(message: 'No internet connection'));
    }
  }

  @override
  Future<Either<Failure, void>> markRecommendationAsRead(String recommendationId, String userId) async {
    if (await networkInfo.isConnected) {
      try {
        await remoteDataSource.markRecommendationAsRead(recommendationId, userId);
        return const Right(null);
      } on FirebaseAuthException catch (e) {
        return Left(AuthFailure(message: e.message ?? 'Firebase Auth Error'));
      } catch (e) {
        return Left(ServerFailure(message: e.toString()));
      }
    } else {
      return const Left(NetworkFailure(message: 'No internet connection'));
    }
  }
}
