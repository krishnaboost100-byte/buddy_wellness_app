import 'package:cloud_firestore/cloud_firestore.dart';
import '../../domain/entities/ai_recommendation_entity.dart';

class AIRecommendationModel extends AIRecommendationEntity {
  const AIRecommendationModel({
    required super.id,
    required super.userId,
    required super.recommendationText,
    required super.category,
    required super.createdAt,
    super.isRead,
  });

  factory AIRecommendationModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return AIRecommendationModel(
      id: doc.id,
      userId: data['userId'],
      recommendationText: data['recommendationText'],
      category: data['category'],
      createdAt: (data['createdAt'] as Timestamp).toDate(),
      isRead: data['isRead'] ?? false,
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'userId': userId,
      'recommendationText': recommendationText,
      'category': category,
      'createdAt': Timestamp.fromDate(createdAt),
      'isRead': isRead,
    };
  }

  factory AIRecommendationModel.fromEntity(AIRecommendationEntity entity) {
    return AIRecommendationModel(
      id: entity.id,
      userId: entity.userId,
      recommendationText: entity.recommendationText,
      category: entity.category,
      createdAt: entity.createdAt,
      isRead: entity.isRead,
    );
  }
}
