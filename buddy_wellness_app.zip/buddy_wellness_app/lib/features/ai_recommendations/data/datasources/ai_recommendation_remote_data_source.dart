import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../../../../services/firebase_service.dart';
import '../../../../services/openai_service.dart';
import '../models/ai_recommendation_model.dart';

abstract class AIRecommendationRemoteDataSource {
  Future<List<AIRecommendationModel>> getAIRecommendations(String userId);
  Future<AIRecommendationModel> generateAIRecommendation(String userId, String prompt);
  Future<void> markRecommendationAsRead(String recommendationId, String userId);
}

class AIRecommendationRemoteDataSourceImpl implements AIRecommendationRemoteDataSource {
  final FirebaseFirestore _firestore;
  final FirebaseAuth _firebaseAuth;
  final OpenAIService _openAIService;

  AIRecommendationRemoteDataSourceImpl({
    FirebaseFirestore? firestore,
    FirebaseAuth? firebaseAuth,
    OpenAIService? openAIService,
  })  : _firestore = firestore ?? FirebaseService.firestore,
        _firebaseAuth = firebaseAuth ?? FirebaseService.auth,
        _openAIService = openAIService ?? OpenAIService(apiKey: 'YOUR_OPENAI_API_KEY'); // TODO: Inject API Key securely

  @override
  Future<List<AIRecommendationModel>> getAIRecommendations(String userId) async {
    final querySnapshot = await _firestore
        .collection('ai_recommendations')
        .where('userId', isEqualTo: userId)
        .orderBy('createdAt', descending: true)
        .get();
    return querySnapshot.docs.map((doc) => AIRecommendationModel.fromFirestore(doc)).toList();
  }

  @override
  Future<AIRecommendationModel> generateAIRecommendation(String userId, String prompt) async {
    final aiResponse = await _openAIService.getAIChatCompletion(prompt);
    final newRecommendation = AIRecommendationModel(
      id: _firestore.collection('ai_recommendations').doc().id,
      userId: userId,
      recommendationText: aiResponse,
      category: 'General',
      createdAt: DateTime.now(),
      isRead: false,
    );
    await _firestore.collection('ai_recommendations').doc(newRecommendation.id).set(newRecommendation.toFirestore());
    return newRecommendation;
  }

  @override
  Future<void> markRecommendationAsRead(String recommendationId, String userId) async {
    await _firestore.collection('ai_recommendations').doc(recommendationId).update({
      'isRead': true,
    });
  }
}
