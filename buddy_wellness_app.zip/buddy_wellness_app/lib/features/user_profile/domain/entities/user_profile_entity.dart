import 'package:equatable/equatable.dart';

class UserProfileEntity extends Equatable {
  final String uid;
  final String? email;
  final String? name;
  final String? photoUrl;
  final List<String>? goals;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final String? subscriptionStatus;
  final DateTime? lastActive;
  final String? selectedLanguage;
  final bool? darkModeEnabled;

  const UserProfileEntity({
    required this.uid,
    this.email,
    this.name,
    this.photoUrl,
    this.goals,
    this.createdAt,
    this.updatedAt,
    this.subscriptionStatus,
    this.lastActive,
    this.selectedLanguage,
    this.darkModeEnabled,
  });

  @override
  List<Object?> get props => [
        uid,
        email,
        name,
        photoUrl,
        goals,
        createdAt,
        updatedAt,
        subscriptionStatus,
        lastActive,
        selectedLanguage,
        darkModeEnabled,
      ];
}
