import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../entities/user_profile_entity.dart';

abstract class UserProfileRepository {
  Future<Either<Failure, UserProfileEntity>> getUserProfile(String uid);
  Future<Either<Failure, void>> updateUserProfile(UserProfileEntity userProfile);
  Future<Either<Failure, void>> deleteUserAccount(String uid);
}
