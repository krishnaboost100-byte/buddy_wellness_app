import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/usecases/usecase.dart';
import '../repositories/user_profile_repository.dart';

class DeleteUserAccount implements UseCase<void, String> {
  final UserProfileRepository repository;

  DeleteUserAccount(this.repository);

  @override
  Future<Either<Failure, void>> call(String uid) async {
    return await repository.deleteUserAccount(uid);
  }
}
