import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/usecases/usecase.dart';
import '../entities/user_profile_entity.dart';
import '../repositories/user_profile_repository.dart';

class UpdateUserProfile implements UseCase<void, UserProfileEntity> {
  final UserProfileRepository repository;

  UpdateUserProfile(this.repository);

  @override
  Future<Either<Failure, void>> call(UserProfileEntity userProfile) async {
    return await repository.updateUserProfile(userProfile);
  }
}
