import 'package:equatable/equatable.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/errors/failures.dart';
import '../../domain/entities/user_profile_entity.dart';
import '../../domain/usecases/get_user_profile.dart';
import '../../domain/usecases/update_user_profile.dart';
import '../../domain/usecases/delete_user_account.dart';

enum UserProfileStatus { initial, loading, loaded, error }

class UserProfileState extends Equatable {
  final UserProfileStatus status;
  final UserProfileEntity? userProfile;
  final Failure? failure;

  const UserProfileState({
    this.status = UserProfileStatus.initial,
    this.userProfile,
    this.failure,
  });

  UserProfileState copyWith({
    UserProfileStatus? status,
    UserProfileEntity? userProfile,
    Failure? failure,
  }) {
    return UserProfileState(
      status: status ?? this.status,
      userProfile: userProfile ?? this.userProfile,
      failure: failure ?? this.failure,
    );
  }

  @override
  List<Object?> get props => [status, userProfile, failure];
}

class UserProfileNotifier extends StateNotifier<UserProfileState> {
  final GetUserProfile _getUserProfile;
  final UpdateUserProfile _updateUserProfile;
  final DeleteUserAccount _deleteUserAccount;

  UserProfileNotifier({
    required GetUserProfile getUserProfile,
    required UpdateUserProfile updateUserProfile,
    required DeleteUserAccount deleteUserAccount,
  })  : _getUserProfile = getUserProfile,
        _updateUserProfile = updateUserProfile,
        _deleteUserAccount = deleteUserAccount,
        super(const UserProfileState());

  Future<void> fetchUserProfile(String uid) async {
    state = state.copyWith(status: UserProfileStatus.loading);
    final result = await _getUserProfile(uid);
    result.fold(
      (failure) => state = state.copyWith(status: UserProfileStatus.error, failure: failure),
      (profile) => state = state.copyWith(status: UserProfileStatus.loaded, userProfile: profile),
    );
  }

  Future<void> updateUserProfile(UserProfileEntity userProfile) async {
    state = state.copyWith(status: UserProfileStatus.loading);
    final result = await _updateUserProfile(userProfile);
    result.fold(
      (failure) => state = state.copyWith(status: UserProfileStatus.error, failure: failure),
      (_) => state = state.copyWith(status: UserProfileStatus.loaded, userProfile: userProfile),
    );
  }

  Future<void> deleteUserAccount(String uid) async {
    state = state.copyWith(status: UserProfileStatus.loading);
    final result = await _deleteUserAccount(uid);
    result.fold(
      (failure) => state = state.copyWith(status: UserProfileStatus.error, failure: failure),
      (_) => state = state.copyWith(status: UserProfileStatus.initial, userProfile: null), // Reset state after deletion
    );
  }
}

final userProfileNotifierProvider = StateNotifierProvider<UserProfileNotifier, UserProfileState>((ref) {
  return UserProfileNotifier(
    getUserProfile: ref.read(getUserProfileProvider),
    updateUserProfile: ref.read(updateUserProfileProvider),
    deleteUserAccount: ref.read(deleteUserAccountProvider),
  );
});


