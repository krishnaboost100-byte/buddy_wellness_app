import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../../../../services/firebase_service.dart';
import '../models/user_profile_model.dart';

abstract class UserProfileRemoteDataSource {
  Future<UserProfileModel> getUserProfile(String uid);
  Future<void> updateUserProfile(UserProfileModel userProfile);
  Future<void> deleteUserAccount(String uid);
}

class UserProfileRemoteDataSourceImpl implements UserProfileRemoteDataSource {
  final FirebaseFirestore _firestore;
  final FirebaseAuth _firebaseAuth;

  UserProfileRemoteDataSourceImpl({
    FirebaseFirestore? firestore,
    FirebaseAuth? firebaseAuth,
  })  : _firestore = firestore ?? FirebaseService.firestore,
        _firebaseAuth = firebaseAuth ?? FirebaseService.auth;

  @override
  Future<UserProfileModel> getUserProfile(String uid) async {
    final doc = await _firestore.collection('users').doc(uid).get();
    if (!doc.exists) {
      throw Exception('User profile not found');
    }
    return UserProfileModel.fromFirestore(doc);
  }

  @override
  Future<void> updateUserProfile(UserProfileModel userProfile) async {
    await _firestore.collection('users').doc(userProfile.uid).update(userProfile.toFirestore());
  }

  @override
  Future<void> deleteUserAccount(String uid) async {
    // Delete user data from Firestore
    await _firestore.collection('users').doc(uid).delete();
    // Delete user from Firebase Authentication
    await _firebaseAuth.currentUser?.delete();
  }
}
