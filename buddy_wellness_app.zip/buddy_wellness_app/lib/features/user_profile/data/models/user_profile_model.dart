import 'package:cloud_firestore/cloud_firestore.dart';
import '../../domain/entities/user_profile_entity.dart';

class UserProfileModel extends UserProfileEntity {
  const UserProfileModel({
    required super.uid,
    super.email,
    super.name,
    super.photoUrl,
    super.goals,
    super.createdAt,
    super.updatedAt,
    super.subscriptionStatus,
    super.lastActive,
    super.selectedLanguage,
    super.darkModeEnabled,
  });

  factory UserProfileModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return UserProfileModel(
      uid: doc.id,
      email: data['email'],
      name: data['name'],
      photoUrl: data['photoUrl'],
      goals: List<String>.from(data['goals'] ?? []),
      createdAt: (data['createdAt'] as Timestamp?)?.toDate(),
      updatedAt: (data['updatedAt'] as Timestamp?)?.toDate(),
      subscriptionStatus: data['subscriptionStatus'],
      lastActive: (data['lastActive'] as Timestamp?)?.toDate(),
      selectedLanguage: data['selectedLanguage'],
      darkModeEnabled: data['darkModeEnabled'],
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'email': email,
      'name': name,
      'photoUrl': photoUrl,
      'goals': goals,
      'createdAt': createdAt != null ? Timestamp.fromDate(createdAt!) : null,
      'updatedAt': updatedAt != null ? Timestamp.fromDate(updatedAt!) : null,
      'subscriptionStatus': subscriptionStatus,
      'lastActive': lastActive != null ? Timestamp.fromDate(lastActive!) : null,
      'selectedLanguage': selectedLanguage,
      'darkModeEnabled': darkModeEnabled,
    };
  }

  factory UserProfileModel.fromEntity(UserProfileEntity entity) {
    return UserProfileModel(
      uid: entity.uid,
      email: entity.email,
      name: entity.name,
      photoUrl: entity.photoUrl,
      goals: entity.goals,
      createdAt: entity.createdAt,
      updatedAt: entity.updatedAt,
      subscriptionStatus: entity.subscriptionStatus,
      lastActive: entity.lastActive,
      selectedLanguage: entity.selectedLanguage,
      darkModeEnabled: entity.darkModeEnabled,
    );
  }
}
