import 'package:equatable/equatable.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/errors/failures.dart';
import '../../domain/entities/user_entity.dart';
import '../../domain/usecases/sign_in_with_email_and_password.dart';
import '../../domain/usecases/sign_up_with_email_and_password.dart';
import '../../domain/usecases/sign_out.dart';

enum AuthStatus { initial, authenticated, unauthenticated, loading, error }

class AuthState extends Equatable {
  final AuthStatus status;
  final UserEntity? user;
  final Failure? failure;

  const AuthState({
    this.status = AuthStatus.initial,
    this.user,
    this.failure,
  });

  AuthState copyWith({
    AuthStatus? status,
    UserEntity? user,
    Failure? failure,
  }) {
    return AuthState(
      status: status ?? this.status,
      user: user ?? this.user,
      failure: failure ?? this.failure,
    );
  }

  @override
  List<Object?> get props => [status, user, failure];
}

class AuthNotifier extends StateNotifier<AuthState> {
  final SignInWithEmailAndPassword _signInWithEmailAndPassword;
  final SignUpWithEmailAndPassword _signUpWithEmailAndPassword;
  final SignOut _signOut;

  AuthNotifier({
    required SignInWithEmailAndPassword signInWithEmailAndPassword,
    required SignUpWithEmailAndPassword signUpWithEmailAndPassword,
    required SignOut signOut,
  })  : _signInWithEmailAndPassword = signInWithEmailAndPassword,
        _signUpWithEmailAndPassword = signUpWithEmailAndPassword,
        _signOut = signOut,
        super(const AuthState());

  Future<void> signIn(String email, String password) async {
    state = state.copyWith(status: AuthStatus.loading);
    final result = await _signInWithEmailAndPassword(SignInParams(email: email, password: password));
    result.fold(
      (failure) => state = state.copyWith(status: AuthStatus.error, failure: failure),
      (user) => state = state.copyWith(status: AuthStatus.authenticated, user: user),
    );
  }

  Future<void> signUp(String email, String password) async {
    state = state.copyWith(status: AuthStatus.loading);
    final result = await _signUpWithEmailAndPassword(SignUpParams(email: email, password: password));
    result.fold(
      (failure) => state = state.copyWith(status: AuthStatus.error, failure: failure),
      (user) => state = state.copyWith(status: AuthStatus.authenticated, user: user),
    );
  }

  Future<void> signOut() async {
    state = state.copyWith(status: AuthStatus.loading);
    final result = await _signOut(NoParams());
    result.fold(
      (failure) => state = state.copyWith(status: AuthStatus.error, failure: failure),
      (_) => state = state.copyWith(status: AuthStatus.unauthenticated, user: null),
    );
  }
}

final authNotifierProvider = StateNotifierProvider<AuthNotifier, AuthState>((ref) {
  // TODO: Implement dependency injection for use cases
  return AuthNotifier(
    signInWithEmailAndPassword: ref.read(signInWithEmailAndPasswordProvider),
    signUpWithEmailAndPassword: ref.read(signUpWithEmailAndPasswordProvider),
    signOut: ref.read(signOutProvider),
  );
});


