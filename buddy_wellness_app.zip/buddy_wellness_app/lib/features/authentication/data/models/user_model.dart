import 'package:firebase_auth/firebase_auth.dart' as firebase_auth;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:equatable/equatable.dart';

class UserModel extends Equatable {
  final String uid;
  final String? email;
  final String? name;
  final String? photoUrl;
  final List<String>? goals;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final String? subscriptionStatus;
  final DateTime? lastActive;

  const UserModel({
    required this.uid,
    this.email,
    this.name,
    this.photoUrl,
    this.goals,
    this.createdAt,
    this.updatedAt,
    this.subscriptionStatus,
    this.lastActive,
  });

  factory UserModel.fromFirebaseUser(firebase_auth.User user) {
    return UserModel(
      uid: user.uid,
      email: user.email,
      name: user.displayName,
      photoUrl: user.photoURL,
      createdAt: user.metadata.creationTime,
      lastActive: user.metadata.lastSignInTime,
    );
  }

  factory UserModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return UserModel(
      uid: doc.id,
      email: data["email"],
      name: data["name"],
      photoUrl: data["photoUrl"],
      goals: List<String>.from(data["goals"] ?? []),
      createdAt: (data["createdAt"] as Timestamp?)?.toDate(),
      updatedAt: (data["updatedAt"] as Timestamp?)?.toDate(),
      subscriptionStatus: data["subscriptionStatus"],
      lastActive: (data["lastActive"] as Timestamp?)?.toDate(),
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      "email": email,
      "name": name,
      "photoUrl": photoUrl,
      "goals": goals,
      "createdAt": createdAt,
      "updatedAt": updatedAt,
      "subscriptionStatus": subscriptionStatus,
      "lastActive": lastActive,
    };
  }

  @override
  List<Object?> get props => [
        uid,
        email,
        name,
        photoUrl,
        goals,
        createdAt,
        updatedAt,
        subscriptionStatus,
        lastActive,
      ];
}
