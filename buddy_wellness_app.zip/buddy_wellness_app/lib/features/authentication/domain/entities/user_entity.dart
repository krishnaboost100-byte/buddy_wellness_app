import 'package:equatable/equatable.dart';

class UserEntity extends Equatable {
  final String uid;
  final String? email;
  final String? name;
  final String? photoUrl;
  final List<String>? goals;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final String? subscriptionStatus;
  final DateTime? lastActive;

  const UserEntity({
    required this.uid,
    this.email,
    this.name,
    this.photoUrl,
    this.goals,
    this.createdAt,
    this.updatedAt,
    this.subscriptionStatus,
    this.lastActive,
  });

  @override
  List<Object?> get props => [
        uid,
        email,
        name,
        photoUrl,
        goals,
        createdAt,
        updatedAt,
        subscriptionStatus,
        lastActive,
      ];
}
