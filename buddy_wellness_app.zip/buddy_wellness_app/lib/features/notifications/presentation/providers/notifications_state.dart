import 'package:equatable/equatable.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/errors/failures.dart';
import '../../domain/entities/notification_entity.dart';
import '../../domain/usecases/get_notifications.dart';
import '../../domain/usecases/mark_notification_as_read.dart';
import '../../domain/usecases/send_notification.dart';

enum NotificationStatus { initial, loading, loaded, error }

class NotificationState extends Equatable {
  final NotificationStatus status;
  final List<NotificationEntity> notifications;
  final Failure? failure;

  const NotificationState({
    this.status = NotificationStatus.initial,
    this.notifications = const [],
    this.failure,
  });

  NotificationState copyWith({
    NotificationStatus? status,
    List<NotificationEntity>? notifications,
    Failure? failure,
  }) {
    return NotificationState(
      status: status ?? this.status,
      notifications: notifications ?? this.notifications,
      failure: failure ?? this.failure,
    );
  }

  @override
  List<Object?> get props => [status, notifications, failure];
}

class NotificationNotifier extends StateNotifier<NotificationState> {
  final GetNotifications _getNotifications;
  final MarkNotificationAsRead _markNotificationAsRead;
  final SendNotification _sendNotification;

  NotificationNotifier({
    required GetNotifications getNotifications,
    required MarkNotificationAsRead markNotificationAsRead,
    required SendNotification sendNotification,
  })  : _getNotifications = getNotifications,
        _markNotificationAsRead = markNotificationAsRead,
        _sendNotification = sendNotification,
        super(const NotificationState());

  Future<void> fetchNotifications(String userId) async {
    state = state.copyWith(status: NotificationStatus.loading);
    final result = await _getNotifications(userId);
    result.fold(
      (failure) => state = state.copyWith(status: NotificationStatus.error, failure: failure),
      (notifications) => state = state.copyWith(status: NotificationStatus.loaded, notifications: notifications),
    );
  }

  Future<void> markAsRead(String notificationId, String userId) async {
    final result = await _markNotificationAsRead(MarkNotificationAsReadParams(notificationId: notificationId, userId: userId));
    result.fold(
      (failure) => state = state.copyWith(status: NotificationStatus.error, failure: failure),
      (_) {
        state = state.copyWith(
          notifications: state.notifications.map((n) => n.id == notificationId ? n.copyWith(isRead: true) : n).toList(),
        );
      },
    );
  }

  Future<void> sendNotification(NotificationEntity notification) async {
    state = state.copyWith(status: NotificationStatus.loading);
    final result = await _sendNotification(notification);
    result.fold(
      (failure) => state = state.copyWith(status: NotificationStatus.error, failure: failure),
      (_) => state = state.copyWith(status: NotificationStatus.loaded), // Or update list if needed
    );
  }
}

final notificationNotifierProvider = StateNotifierProvider<NotificationNotifier, NotificationState>((ref) {
  return NotificationNotifier(
    getNotifications: ref.read(getNotificationsProvider),
    markNotificationAsRead: ref.read(markNotificationAsReadProvider),
    sendNotification: ref.read(sendNotificationProvider),
  );
});


