import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../../../../services/firebase_service.dart';
import '../models/notification_model.dart';

abstract class NotificationRemoteDataSource {
  Future<List<NotificationModel>> getNotifications(String userId);
  Future<void> markNotificationAsRead(String notificationId, String userId);
  Future<void> sendNotification(NotificationModel notification);
}

class NotificationRemoteDataSourceImpl implements NotificationRemoteDataSource {
  final FirebaseFirestore _firestore;
  final FirebaseAuth _firebaseAuth;

  NotificationRemoteDataSourceImpl({
    FirebaseFirestore? firestore,
    FirebaseAuth? firebaseAuth,
  })  : _firestore = firestore ?? FirebaseService.firestore,
        _firebaseAuth = firebaseAuth ?? FirebaseService.auth;

  @override
  Future<List<NotificationModel>> getNotifications(String userId) async {
    final querySnapshot = await _firestore
        .collection('notifications')
        .where('userId', isEqualTo: userId)
        .orderBy('scheduledAt', descending: true)
        .get();
    return querySnapshot.docs.map((doc) => NotificationModel.fromFirestore(doc)).toList();
  }

  @override
  Future<void> markNotificationAsRead(String notificationId, String userId) async {
    await _firestore.collection('notifications').doc(notificationId).update({
      'isRead': true,
    });
  }

  @override
  Future<void> sendNotification(NotificationModel notification) async {
    await _firestore.collection('notifications').add(notification.toFirestore());
    // In a real app, this would also trigger Firebase Cloud Messaging to send the push notification.
  }
}
