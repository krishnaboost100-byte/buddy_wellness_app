import 'package:cloud_firestore/cloud_firestore.dart';
import '../../domain/entities/notification_entity.dart';

class NotificationModel extends NotificationEntity {
  const NotificationModel({
    super.id,
    super.userId,
    required super.title,
    required super.body,
    required super.type,
    required super.scheduledAt,
    super.sentAt,
    super.isRead,
    super.targetScreen,
  });

  factory NotificationModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return NotificationModel(
      id: doc.id,
      userId: data['userId'],
      title: data['title'],
      body: data['body'],
      type: data['type'],
      scheduledAt: (data['scheduledAt'] as Timestamp).toDate(),
      sentAt: (data['sentAt'] as Timestamp?)?.toDate(),
      isRead: data['isRead'] ?? false,
      targetScreen: data['targetScreen'],
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'userId': userId,
      'title': title,
      'body': body,
      'type': type,
      'scheduledAt': Timestamp.fromDate(scheduledAt),
      'sentAt': sentAt != null ? Timestamp.fromDate(sentAt!) : null,
      'isRead': isRead,
      'targetScreen': targetScreen,
    };
  }

  factory NotificationModel.fromEntity(NotificationEntity entity) {
    return NotificationModel(
      id: entity.id,
      userId: entity.userId,
      title: entity.title,
      body: entity.body,
      type: entity.type,
      scheduledAt: entity.scheduledAt,
      sentAt: entity.sentAt,
      isRead: entity.isRead,
      targetScreen: entity.targetScreen,
    );
  }
}
