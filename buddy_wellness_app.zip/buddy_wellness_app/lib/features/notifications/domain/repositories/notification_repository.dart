import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../entities/notification_entity.dart';

abstract class NotificationRepository {
  Future<Either<Failure, List<NotificationEntity>>> getNotifications(String userId);
  Future<Either<Failure, void>> markNotificationAsRead(String notificationId, String userId);
  Future<Either<Failure, void>> sendNotification(NotificationEntity notification);
}
