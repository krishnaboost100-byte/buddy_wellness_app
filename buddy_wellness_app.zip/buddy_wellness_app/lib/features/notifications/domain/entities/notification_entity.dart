import 'package:equatable/equatable.dart';

class NotificationEntity extends Equatable {
  final String? id;
  final String? userId;
  final String title;
  final String body;
  final String type;
  final DateTime scheduledAt;
  final DateTime? sentAt;
  final bool isRead;
  final String? targetScreen;

  const NotificationEntity({
    this.id,
    this.userId,
    required this.title,
    required this.body,
    required this.type,
    required this.scheduledAt,
    this.sentAt,
    this.isRead = false,
    this.targetScreen,
  });

  @override
  List<Object?> get props => [
        id,
        userId,
        title,
        body,
        type,
        scheduledAt,
        sentAt,
        isRead,
        targetScreen,
      ];
}
