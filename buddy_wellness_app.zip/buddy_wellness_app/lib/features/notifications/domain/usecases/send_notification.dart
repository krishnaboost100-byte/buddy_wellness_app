import 'package:dartz/dartz.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/usecases/usecase.dart';
import '../entities/notification_entity.dart';
import '../repositories/notification_repository.dart';

class SendNotification implements UseCase<void, NotificationEntity> {
  final NotificationRepository repository;

  SendNotification(this.repository);

  @override
  Future<Either<Failure, void>> call(NotificationEntity notification) async {
    return await repository.sendNotification(notification);
  }
}
