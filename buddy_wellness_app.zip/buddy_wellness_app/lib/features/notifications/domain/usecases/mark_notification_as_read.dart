import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/usecases/usecase.dart';
import '../repositories/notification_repository.dart';

class MarkNotificationAsRead implements UseCase<void, MarkNotificationAsReadParams> {
  final NotificationRepository repository;

  MarkNotificationAsRead(this.repository);

  @override
  Future<Either<Failure, void>> call(MarkNotificationAsReadParams params) async {
    return await repository.markNotificationAsRead(params.notificationId, params.userId);
  }
}

class MarkNotificationAsReadParams extends Equatable {
  final String notificationId;
  final String userId;

  const MarkNotificationAsReadParams({required this.notificationId, required this.userId});

  @override
  List<Object?> get props => [notificationId, userId];
}
