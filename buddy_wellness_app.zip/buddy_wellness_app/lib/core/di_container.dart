import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:internet_connection_checker_plus/internet_connection_checker_plus.dart';

import '../../features/authentication/data/datasources/auth_remote_data_source.dart';
import '../../features/authentication/data/repositories/auth_repository_impl.dart';
import '../../features/authentication/domain/repositories/auth_repository.dart';
import '../../features/authentication/domain/usecases/sign_in_with_email_and_password.dart';
import '../../features/authentication/domain/usecases/sign_up_with_email_and_password.dart';
import '../../features/authentication/domain/usecases/sign_out.dart';
import '../network/network_info.dart';

// Core
final networkInfoProvider = Provider<NetworkInfo>((ref) => NetworkInfoImpl(InternetConnectionCheckerPlus()));

import 'package:buddy_wellness_app/features/dashboard/data/datasources/dashboard_remote_data_source.dart';
import 'package:buddy_wellness_app/features/dashboard/data/repositories/dashboard_repository_impl.dart';
import 'package:buddy_wellness_app/features/dashboard/domain/repositories/dashboard_repository.dart';
import 'package:buddy_wellness_app/features/dashboard/domain/usecases/get_dashboard_data.dart';

// Authentication Feature
final authRemoteDataSourceProvider = Provider<AuthRemoteDataSource>((ref) => AuthRemoteDataSourceImpl());

final authRepositoryProvider = Provider<AuthRepository>((ref) => AuthRepositoryImpl(
      remoteDataSource: ref.read(authRemoteDataSourceProvider),
      networkInfo: ref.read(networkInfoProvider),
    ));

final signInWithEmailAndPasswordProvider = Provider<SignInWithEmailAnd
Password>(
    (ref) => SignInWithEmailAndPassword(ref.read(authRepositoryProvider)));

final signUpWithEmailAndPasswordProvider = Provider<SignUpWithEmailAnd
Password>(
    (ref) => SignUpWithEmailAnd
Password(ref.read(authRepositoryProvider)));

final signOutProvider = Provider<SignOut>(
    (ref) => SignOut(ref.read(authRepositoryProvider)));

// Dashboard Feature
final dashboardRemoteDataSourceProvider = Provider<DashboardRemoteDataSource>((ref) => DashboardRemoteDataSourceImpl());

final dashboardRepositoryProvider = Provider<DashboardRepository>((ref) => DashboardRepositoryImpl(
      remoteDataSource: ref.read(dashboardRemoteDataSourceProvider),
      networkInfo: ref.read(networkInfoProvider),
    ));

final getDashboardDataProvider = Provider<GetDashboardData>(
    (ref) => GetDashboardData(ref.read(dashboardRepositoryProvider)));

// Habit Management Feature
import 'package:buddy_wellness_app/features/habit_management/data/datasources/habit_remote_data_source.dart';
import 'package:buddy_wellness_app/features/habit_management/data/repositories/habit_repository_impl.dart';
import 'package:buddy_wellness_app/features/habit_management/domain/repositories/habit_repository.dart';
import 'package:buddy_wellness_app/features/habit_management/domain/usecases/create_habit.dart';
import 'package:buddy_wellness_app/features/habit_management/domain/usecases/delete_habit.dart';
import 'package:buddy_wellness_app/features/habit_management/domain/usecases/get_habits.dart';
import 'package:buddy_wellness_app/features/habit_management/domain/usecases/update_habit.dart';

final habitRemoteDataSourceProvider = Provider<HabitRemoteDataSource>((ref) => HabitRemoteDataSourceImpl());

final habitRepositoryProvider = Provider<HabitRepository>((ref) => HabitRepositoryImpl(
      remoteDataSource: ref.read(habitRemoteDataSourceProvider),
      networkInfo: ref.read(networkInfoProvider),
    ));

final getHabitsProvider = Provider<GetHabits>(
    (ref) => GetHabits(ref.read(habitRepositoryProvider)));

final createHabitProvider = Provider<CreateHabit>(
    (ref) => CreateHabit(ref.read(habitRepositoryProvider)));

final updateHabitProvider = Provider<UpdateHabit>(
    (ref) => UpdateHabit(ref.read(habitRepositoryProvider)));

final deleteHabitProvider = Provider<DeleteHabit>(
    (ref) => DeleteHabit(ref.read(habitRepositoryProvider)));

// AI Recommendations Feature
import 'package:buddy_wellness_app/features/ai_recommendations/data/datasources/ai_recommendation_remote_data_source.dart';
import 'package:buddy_wellness_app/features/ai_recommendations/data/repositories/ai_recommendation_repository_impl.dart';
import 'package:buddy_wellness_app/features/ai_recommendations/domain/repositories/ai_recommendation_repository.dart';
import 'package:buddy_wellness_app/features/ai_recommendations/domain/usecases/generate_ai_recommendation.dart';
import 'package:buddy_wellness_app/features/ai_recommendations/domain/usecases/get_ai_recommendations.dart';

final aiRecommendationRemoteDataSourceProvider = Provider<AIRecommendationRemoteDataSource>((ref) => AIRecommendationRemoteDataSourceImpl());

final aiRecommendationRepositoryProvider = Provider<AIRecommendationRepository>((ref) => AIRecommendationRepositoryImpl(
      remoteDataSource: ref.read(aiRecommendationRemoteDataSourceProvider),
      networkInfo: ref.read(networkInfoProvider),
    ));

final getAIRecommendationsProvider = Provider<GetAIRecommendations>(
    (ref) => GetAIRecommendations(ref.read(aiRecommendationRepositoryProvider)));

final generateAIRecommendationProvider = Provider<GenerateAIRecommendation>(
    (ref) => GenerateAIRecommendation(ref.read(aiRecommendationRepositoryProvider)));

// Notifications Feature
import 'package:buddy_wellness_app/features/notifications/data/datasources/notification_remote_data_source.dart';
import 'package:buddy_wellness_app/features/notifications/data/repositories/notification_repository_impl.dart';
import 'package:buddy_wellness_app/features/notifications/domain/repositories/notification_repository.dart';
import 'package:buddy_wellness_app/features/notifications/domain/usecases/get_notifications.dart';
import 'package:buddy_wellness_app/features/notifications/domain/usecases/mark_notification_as_read.dart';
import 'package:buddy_wellness_app/features/notifications/domain/usecases/send_notification.dart';

final notificationRemoteDataSourceProvider = Provider<NotificationRemoteDataSource>((ref) => NotificationRemoteDataSourceImpl());

final notificationRepositoryProvider = Provider<NotificationRepository>((ref) => NotificationRepositoryImpl(
      remoteDataSource: ref.read(notificationRemoteDataSourceProvider),
      networkInfo: ref.read(networkInfoProvider),
    ));

final getNotificationsProvider = Provider<GetNotifications>(
    (ref) => GetNotifications(ref.read(notificationRepositoryProvider)));

final markNotificationAsReadProvider = Provider<MarkNotificationAsRead>(
    (ref) => MarkNotificationAsRead(ref.read(notificationRepositoryProvider)));

final sendNotificationProvider = Provider<SendNotification>(
    (ref) => SendNotification(ref.read(notificationRepositoryProvider)));

// Streak System Feature
import 'package:buddy_wellness_app/features/streak_system/data/datasources/streak_remote_data_source.dart';
import 'package:buddy_wellness_app/features/streak_system/data/repositories/streak_repository_impl.dart';
import 'package:buddy_wellness_app/features/streak_system/domain/repositories/streak_repository.dart';
import 'package:buddy_wellness_app/features/streak_system/domain/usecases/create_or_update_streak.dart';
import 'package:buddy_wellness_app/features/streak_system/domain/usecases/get_streak_by_id.dart';
import 'package:buddy_wellness_app/features/streak_system/domain/usecases/get_streaks.dart';

final streakRemoteDataSourceProvider = Provider<StreakRemoteDataSource>((ref) => StreakRemoteDataSourceImpl());

final streakRepositoryProvider = Provider<StreakRepository>((ref) => StreakRepositoryImpl(
      remoteDataSource: ref.read(streakRemoteDataSourceProvider),
      networkInfo: ref.read(networkInfoProvider),
    ));

final getStreaksProvider = Provider<GetStreaks>(
    (ref) => GetStreaks(ref.read(streakRepositoryProvider)));

final getStreakByIdProvider = Provider<GetStreakById>(
    (ref) => GetStreakById(ref.read(streakRepositoryProvider)));

final createOrUpdateStreakProvider = Provider<CreateOrUpdateStreak>(
    (ref) => CreateOrUpdateStreak(ref.read(streakRepositoryProvider)));

// User Profile Feature
import 'package:buddy_wellness_app/features/user_profile/data/datasources/user_profile_remote_data_source.dart';
import 'package:buddy_wellness_app/features/user_profile/data/repositories/user_profile_repository_impl.dart';
import 'package:buddy_wellness_app/features/user_profile/domain/repositories/user_profile_repository.dart';
import 'package:buddy_wellness_app/features/user_profile/domain/usecases/delete_user_account.dart';
import 'package:buddy_wellness_app/features/user_profile/domain/usecases/get_user_profile.dart';
import 'package:buddy_wellness_app/features/user_profile/domain/usecases/update_user_profile.dart';

final userProfileRemoteDataSourceProvider = Provider<UserProfileRemoteDataSource>((ref) => UserProfileRemoteDataSourceImpl());

final userProfileRepositoryProvider = Provider<UserProfileRepository>((ref) => UserProfileRepositoryImpl(
      remoteDataSource: ref.read(userProfileRemoteDataSourceProvider),
      networkInfo: ref.read(networkInfoProvider),
    ));

final getUserProfileProvider = Provider<GetUserProfile>(
    (ref) => GetUserProfile(ref.read(userProfileRepositoryProvider)));

final updateUserProfileProvider = Provider<UpdateUserProfile>(
    (ref) => UpdateUserProfile(ref.read(userProfileRepositoryProvider)));

final deleteUserAccountProvider = Provider<DeleteUserAccount>(
    (ref) => DeleteUserAccount(ref.read(userProfileRepositoryProvider)));

// Analytics Feature
import 'package:buddy_wellness_app/features/analytics/data/datasources/analytics_remote_data_source.dart';
import 'package:buddy_wellness_app/features/analytics/data/repositories/analytics_repository_impl.dart';
import 'package:buddy_wellness_app/features/analytics/domain/repositories/analytics_repository.dart';
import 'package:buddy_wellness_app/features/analytics/domain/usecases/get_analytics_data.dart';
import 'package:buddy_wellness_app/features/analytics/domain/usecases/save_analytics_data.dart';

final analyticsRemoteDataSourceProvider = Provider<AnalyticsRemoteDataSource>((ref) => AnalyticsRemoteDataSourceImpl());

final analyticsRepositoryProvider = Provider<AnalyticsRepository>((ref) => AnalyticsRepositoryImpl(
      remoteDataSource: ref.read(analyticsRemoteDataSourceProvider),
      networkInfo: ref.read(networkInfoProvider),
    ));

final getAnalyticsDataProvider = Provider<GetAnalyticsData>(
    (ref) => GetAnalyticsData(ref.read(analyticsRepositoryProvider)));

final saveAnalyticsDataProvider = Provider<SaveAnalyticsData>(
    (ref) => SaveAnalyticsData(ref.read(analyticsRepositoryProvider)));

// Settings Feature
import 'package:buddy_wellness_app/features/settings/data/datasources/settings_remote_data_source.dart';
import 'package:buddy_wellness_app/features/settings/data/repositories/settings_repository_impl.dart';
import 'package:buddy_wellness_app/features/settings/domain/repositories/settings_repository.dart';
import 'package:buddy_wellness_app/features/settings/domain/usecases/get_settings.dart';
import 'package:buddy_wellness_app/features/settings/domain/usecases/update_settings.dart';

final settingsRemoteDataSourceProvider = Provider<SettingsRemoteDataSource>((ref) => SettingsRemoteDataSourceImpl());

final settingsRepositoryProvider = Provider<SettingsRepository>((ref) => SettingsRepositoryImpl(
      remoteDataSource: ref.read(settingsRemoteDataSourceProvider),
      networkInfo: ref.read(networkInfoProvider),
    ));

final getSettingsProvider = Provider<GetSettings>(
    (ref) => GetSettings(ref.read(settingsRepositoryProvider)));

final updateSettingsProvider = Provider<UpdateSettings>(
    (ref) => UpdateSettings(ref.read(settingsRepositoryProvider)));
