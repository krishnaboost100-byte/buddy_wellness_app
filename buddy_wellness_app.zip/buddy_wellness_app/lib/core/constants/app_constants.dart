class AppConstants {
  static const String hiveAppBox = 'buddy_wellness_box';
  static const String appName = 'Buddy Wellness AI';
  static const String defaultLanguage = 'en';
  // Add other app-wide constants here
}
