import 'package:firebase_core/firebase_core.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:buddy_wellness_app/core/di_container.dart' as di;

import 'app.dart';
import 'core/constants/app_constants.dart';
import 'services/firebase_service.dart';
import 'services/local_storage_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize Firebase
  await Firebase.initializeApp();
  // Initialize Firebase services
  await FirebaseService.init();
  MobileAds.instance.initialize(); // Initialize Google Mobile Ads();

  // Initialize Hive (local database)
  await Hive.initFlutter();
  await Hive.openBox(AppConstants.hiveAppBox);

  // Initialize Shared Preferences
  await LocalStorageService.init();

  runApp(const ProviderScope(child: MyApp()));
}
