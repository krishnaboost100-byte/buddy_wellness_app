import 'package:openai_dart/openai_dart.dart';

class OpenAIService {
  final OpenAI _openAI;

  OpenAIService({required String apiKey}) : _openAI = OpenAI(apiKey: apiKey);

  Future<String> getAIChatCompletion(String prompt) async {
    try {
      final chatCompletion = await _openAI.createChatCompletion(
        request: CreateChatCompletionRequest(
          model: ChatCompletionModel.modelId("gpt-3.5-turbo"), // Or gpt-4
          messages: [
            ChatCompletionMessage.system(
              content: "You are a helpful assistant for a wellness and habit tracking app.",
            ),
            ChatCompletionMessage.user(content: prompt),
          ],
        ),
      );
      return chatCompletion.choices.first.message.content ?? "";
    } catch (e) {
      print("Error getting AI chat completion: $e");
      return "";
    }
  }

  // Add more OpenAI related methods here, e.g., for habit analysis, personalized recommendations
}
