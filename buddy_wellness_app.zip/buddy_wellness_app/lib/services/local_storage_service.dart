import 'package:shared_preferences/shared_preferences.dart';
import 'package:hive/hive.dart';

import '../core/constants/app_constants.dart';

class LocalStorageService {
  static late SharedPreferences _preferences;
  static late Box _appBox;

  static Future<void> init() async {
    _preferences = await SharedPreferences.getInstance();
    _appBox = await Hive.openBox(AppConstants.hiveAppBox);
  }

  // SharedPreferences methods
  static Future<bool> setBool(String key, bool value) async =>
      await _preferences.setBool(key, value);
  static bool? getBool(String key) => _preferences.getBool(key);

  static Future<bool> setString(String key, String value) async =>
      await _preferences.setString(key, value);
  static String? getString(String key) => _preferences.getString(key);

  // Hive methods
  static Future<void> put(dynamic key, dynamic value) async =>
      await _appBox.put(key, value);
  static dynamic get(dynamic key) => _appBox.get(key);
  static Future<void> delete(dynamic key) async => await _appBox.delete(key);
}
