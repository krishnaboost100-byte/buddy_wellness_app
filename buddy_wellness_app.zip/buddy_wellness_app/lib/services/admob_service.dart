import 'package:google_mobile_ads/google_mobile_ads.dart';

class AdMobService {
  static String get bannerAdUnitId =>
      // Replace with your actual AdMob banner ad unit ID
      // For testing, you can use: "ca-app-pub-3940256099942544/6300978111";
      "ca-app-pub-xxxxxxxxxxxxxxxx/yyyyyyyyyy"; 

  static String get interstitialAdUnitId =>
      // Replace with your actual AdMob interstitial ad unit ID
      // For testing, you can use: "ca-app-pub-3940256099942544/1033173712";
      "ca-app-pub-xxxxxxxxxxxxxxxx/zzzzzzzzzz";

  static BannerAd getBannerAd() {
    return BannerAd(
      adUnitId: bannerAdUnitId,
      request: const AdRequest(),
      size: AdSize.banner,
      listener: BannerAdListener(
        onAdLoaded: (ad) => print("Banner Ad loaded."),
        onAdFailedToLoad: (ad, err) {
          print("Banner Ad failed to load: $err");
          ad.dispose();
        },
      ),
    );
  }

  static InterstitialAd? _interstitialAd;

  static void loadInterstitialAd() {
    InterstitialAd.load(
      adUnitId: interstitialAdUnitId,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) {
          _interstitialAd = ad;
          print("Interstitial Ad loaded.");
        },
        onAdFailedToLoad: (err) {
          print("Interstitial Ad failed to load: $err");
        },
      ),
    );
  }

  static void showInterstitialAd() {
    if (_interstitialAd == null) {
      print("Warning: Interstitial Ad not loaded.");
      return;
    }
    _interstitialAd!.fullScreenContentCallback = FullScreenContentCallback(
      onAdShowedFullScreenContent: (ad) => print("Interstitial Ad showed full screen content."),
      onAdDismissedFullScreenContent: (ad) {
        print("Interstitial Ad dismissed full screen content.");
        ad.dispose();
        _interstitialAd = null;
        loadInterstitialAd(); // Load a new ad for the next time
      },
      onAdFailedToShowFullScreenContent: (ad, err) {
        print("Interstitial Ad failed to show full screen content: $err");
        ad.dispose();
        _interstitialAd = null;
        loadInterstitialAd(); // Load a new ad for the next time
      },
    );
    _interstitialAd!.show();
  }
}
