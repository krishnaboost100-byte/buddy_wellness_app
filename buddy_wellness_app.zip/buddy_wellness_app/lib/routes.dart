import 'package:go_router/go_router.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter/material.dart';

import 'package:buddy_wellness_app/features/onboarding/presentation/screens/onboarding_screen.dart';
import 'package:buddy_wellness_app/features/authentication/presentation/screens/auth_screen.dart';
import 'package:buddy_wellness_app/features/dashboard/presentation/screens/home_screen.dart';

final goRouterProvider = Provider<GoRouter>((ref) {
  return GoRouter(
    initialLocation: '/onboarding',
    routes: [
      GoRoute(
        path: '/onboarding',
        builder: (context, state) => const OnboardingScreen(),
      ),
      GoRoute(
        path: '/auth',
        builder: (context, state) => const AuthScreen(),
      ),
      GoRoute(
        path: '/home',
        builder: (context, state) => const HomeScreen(),
      ),
      // TODO: Add more routes for other features
    ],
    // TODO: Implement error handling and redirects (e.g., for unauthenticated users)
  );
});
