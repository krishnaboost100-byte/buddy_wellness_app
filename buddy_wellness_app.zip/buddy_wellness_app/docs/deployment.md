# Buddy Wellness App Deployment Guide

This guide provides comprehensive instructions for deploying the various components of the Buddy Wellness application to their respective production environments. This includes the mobile application (Android & iOS), the Flutter Web Admin Panel, and the static marketing landing website.

## 1. Mobile Application Deployment (Android & iOS)

Deploying the Flutter mobile application involves building release versions for Android and iOS and submitting them to the Google Play Store and Apple App Store, respectively.

### 1.1. Before You Begin

-   **Firebase Project**: Ensure your Firebase project is fully configured for both Android and iOS, including `google-services.json` and `GoogleService-Info.plist` files.
-   **App Store Accounts**: You need a Google Play Developer account and an Apple Developer Program membership.
-   **App Icons & Splash Screens**: Prepare all necessary app icons and splash screen assets.
-   **Privacy Policy & Terms of Service**: Have links to your Privacy Policy and Terms of Service ready, as they are required by both app stores.
-   **AdMob Setup**: If using AdMob, ensure your ad units are created and linked to your app in the AdMob console.

### 1.2. Android Deployment

1.  **Update `pubspec.yaml`**: Ensure your `version` and `build` numbers are correctly incremented.

2.  **Build an App Bundle (Recommended)**:
    Navigate to the `buddy_wellness_app` directory and run:
    ```bash
    flutter build appbundle --release
    ```
    This generates an Android App Bundle (`.aab` file) in `build/app/outputs/bundle/release/app-release.aab`.

3.  **Upload to Google Play Console**:
    -   Go to the [Google Play Console](https://play.google.com/console).
    -   Create a new application or select an existing one.
    -   Go to "Release management" > "App releases" and create a new release.
    -   Upload your `.aab` file.
    -   Provide all required information: store listing details, content rating, pricing, and distribution.
    -   Review and roll out your release.

### 1.3. iOS Deployment

1.  **Update `pubspec.yaml`**: Ensure your `version` and `build` numbers are correctly incremented.

2.  **Open in Xcode**:
    Navigate to the `buddy_wellness_app/ios` directory and open `Runner.xcworkspace` in Xcode.

3.  **Configure Signing & Capabilities**:
    -   In Xcode, select your project in the Navigator.
    -   Go to the "Signing & Capabilities" tab.
    -   Select your development team and ensure automatic signing is enabled, or manually manage your provisioning profiles.
    -   Add any necessary capabilities (e.g., Push Notifications, In-App Purchases).

4.  **Build for Archiving**:
    -   Select a "Generic iOS Device" as the target.
    -   Go to "Product" > "Archive".
    -   Once archiving is complete, the Xcode Organizer will open.

5.  **Distribute to App Store Connect**:
    -   In the Xcode Organizer, select your archive and click "Distribute App".
    -   Choose "App Store Connect" as the distribution method.
    -   Follow the prompts to upload your app to App Store Connect.

6.  **Submit for Review in App Store Connect**:
    -   Go to [App Store Connect](https://appstoreconnect.apple.com/).
    -   Select your app and navigate to the "TestFlight" or "App Store" tab.
    -   Provide all required information: app metadata, screenshots, privacy policy, and export compliance.
    -   Submit your app for review.

## 2. Admin Panel Deployment (Flutter Web)

The Flutter Web Admin Panel can be deployed to any static web hosting service. Firebase Hosting is highly recommended for its seamless integration with your Firebase project.

### 2.1. Build the Web Application

Navigate to the `buddy_wellness_app/admin_panel` directory and run:
```bash
flutter build web --release
```
This command generates optimized web build files in the `buddy_wellness_app/admin_panel/build/web` directory.

### 2.2. Deploy with Firebase Hosting (Recommended)

1.  **Initialize Firebase Hosting**:
    If you haven't already, initialize Firebase Hosting from the root of your `buddy_wellness_app` project:
    ```bash
    firebase init hosting
    ```
    -   Select your Firebase project.
    -   For the public directory, specify `admin_panel/build/web`.
    -   Configure as a single-page app: `Yes`.
    -   Set up automatic builds and deploys with GitHub: `No` (unless you want to configure CI/CD separately).

2.  **Deploy to Firebase Hosting**:
    From the `buddy_wellness_app` directory, deploy your web app:
    ```bash
    firebase deploy --only hosting
    ```
    Firebase will provide you with a hosting URL upon successful deployment.

### 2.3. Other Hosting Options

Alternatively, you can deploy the contents of the `build/web` directory to any static site hosting provider such as Netlify, Vercel, AWS S3 with CloudFront, or GitHub Pages.

## 3. Landing Website Deployment (HTML/CSS/JS)

The static marketing landing website is a simple HTML/CSS/JS site and can be deployed to any static web hosting service.

### 3.1. Deployment Steps

1.  **Prepare Files**: Ensure all your `index.html`, `styles.css`, `script.js`, and `assets` files are in the `buddy_wellness_app/landing_website` directory.

2.  **Choose a Hosting Service**:
    -   **Firebase Hosting**: Recommended for integration with your Firebase project. From the `buddy_wellness_app` directory, you can configure a separate hosting site for the landing page or deploy it to a subdirectory of your main Firebase Hosting site.
        -   To configure a separate site:
            ```bash
            firebase init hosting
            ```
            When prompted for the public directory, specify `landing_website`.
        -   Then deploy:
            ```bash
            firebase deploy --only hosting:<your-landing-site-id>
            ```
    -   **Netlify/Vercel**: Excellent for continuous deployment from Git repositories. Simply link your `buddy_wellness_app/landing_website` directory to a new project.
    -   **GitHub Pages**: Free hosting directly from a GitHub repository.
    -   **AWS S3 + CloudFront**: For highly scalable and performant static site hosting.

## 4. Firebase Security Rules Deployment

After configuring your Firestore database, you need to deploy the security rules to protect your data.

1.  **Review Rules**: Ensure your `firestore.rules` file (located at `buddy_wellness_app/firestore.rules`) is up-to-date and correctly defines access controls.

2.  **Deploy Rules**:
    From the root of your `buddy_wellness_app` project, run:
    ```bash
    firebase deploy --only firestore:rules
    ```
    This will apply the rules to your Firestore database.

## 5. Continuous Integration/Continuous Deployment (CI/CD)

For automated builds, tests, and deployments, consider setting up CI/CD pipelines using services like GitHub Actions, GitLab CI/CD, or Bitbucket Pipelines. This will streamline your development workflow and ensure consistent deployments.

### 5.1. Example CI/CD Workflow (GitHub Actions)

A typical GitHub Actions workflow for a Flutter project might include:

-   **On Push**: Run `flutter analyze`, `flutter test`, and `flutter build` for both mobile and web.
-   **On Release Tag**: Automatically deploy to Google Play, App Store Connect, and Firebase Hosting.

Refer to the documentation of your chosen CI/CD service for specific configuration details.
