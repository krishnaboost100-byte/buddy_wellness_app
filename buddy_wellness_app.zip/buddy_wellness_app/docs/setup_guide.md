# Buddy Wellness App Setup Guide

This guide provides detailed instructions on how to set up the development environment for the Buddy Wellness application, including the mobile app, admin panel, and landing website. It covers prerequisites, Firebase configuration, and running each component locally.

## 1. Prerequisites

Before you begin, ensure you have the following installed on your development machine:

-   **Flutter SDK**: [Installation Guide](https://flutter.dev/docs/get-started/install)
    -   Verify installation: `flutter doctor`
-   **Node.js & npm/yarn**: For web development tools.
    -   [Node.js Download](https://nodejs.org/en/download/)
-   **Git**: Version control system.
    -   [Git Download](https://git-scm.com/downloads)
-   **VS Code (Recommended IDE)**: With Flutter and Dart extensions.
    -   [VS Code Download](https://code.visualstudio.com/)
-   **Firebase CLI**: For interacting with Firebase projects.
    -   Install: `npm install -g firebase-tools`
    -   Login: `firebase login`

## 2. Project Setup

1.  **Clone the Repository**:
    ```bash
    git clone <repository_url>
    cd buddy_wellness_app
    ```

2.  **Install Flutter Dependencies**:
    Navigate to the root of the `buddy_wellness_app` directory and run:
    ```bash
    flutter pub get
    ```
    Do the same for the `admin_panel` directory:
    ```bash
    cd admin_panel
    flutter pub get
    cd ..
    ```

## 3. Firebase Project Configuration

Buddy Wellness relies heavily on Firebase for its backend. Follow these steps to set up your Firebase project.

### 3.1. Create a Firebase Project

1.  Go to the [Firebase Console](https://console.firebase.google.com/).
2.  Click 
