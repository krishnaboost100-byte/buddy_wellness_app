# Buddy Wellness Admin Panel Guide

This guide provides instructions for setting up, deploying, and using the Flutter Web Admin Panel for the Buddy Wellness application. The Admin Panel allows authorized personnel to manage users, monitor app activity, and configure various aspects of the application.

## 1. Overview

The Admin Panel is a separate Flutter Web application designed to provide administrative functionalities. It connects directly to the same Firebase project as the mobile application, allowing for real-time management of user data and app settings.

## 2. Setup and Local Development

To set up and run the Admin Panel locally, follow these steps:

1.  **Navigate to the Admin Panel Directory**:
    ```bash
    cd buddy_wellness_app/admin_panel
    ```

2.  **Install Dependencies**:
    Ensure all Flutter dependencies are installed:
    ```bash
    flutter pub get
    ```

3.  **Firebase Configuration**:
    The Admin Panel requires Firebase configuration. If you haven't already, register a web app in your Firebase project and create the `firebase_options.dart` file as described in the [Setup Guide](docs/setup_guide.md#323-register-web-app-for-admin-panel).

4.  **Run Locally**:
    To run the Admin Panel in your browser, execute:
    ```bash
    flutter run -d chrome
    ```
    This will launch the application in a new Chrome window.

## 3. Admin User Access

Access to the Admin Panel is restricted to users with administrative privileges. This is managed through the `isAdmin` field in the `users` collection in Firestore and enforced by [Firebase Security Rules](docs/architecture.md#4-firebase-security-rules).

To grant admin access to a user:

1.  Go to your Firebase Console.
2.  Navigate to "Build > Firestore Database".
3.  Find the `users` collection.
4.  Locate the document corresponding to the user you wish to grant admin access.
5.  Add a new field named `isAdmin` with a boolean value of `true`.

    **Note**: For a more robust production environment, consider using [Firebase Custom Claims](https://firebase.google.com/docs/auth/admin/custom-claims) for managing user roles.

## 4. Key Features

### 4.1. User Management
-   **View Users**: Browse a list of all registered users.
-   **User Details**: View detailed profiles of individual users.
-   **Edit User Data**: Modify user information (e.g., name, email, subscription status).
-   **Delete User**: Remove user accounts.

### 4.2. Habit Oversight
-   **Monitor Habits**: View overall habit creation and completion trends across all users.
-   **Search/Filter Habits**: Search for specific habits or filter by category.

### 4.3. Analytics Dashboard
-   **App Usage Metrics**: Track active users, new registrations, and session durations.
-   **Wellness Trends**: Monitor aggregated wellness scores and mood data.
-   **Habit Performance**: Analyze completion rates for popular habits.

### 4.4. Content Management
-   **AI Prompts**: Manage and update the prompts used for AI recommendations.
-   **Motivational Content**: Curate and update motivational quotes or tips displayed in the app.

### 4.5. Settings
-   **Global App Settings**: Configure features that affect all users (e.g., default notification settings, feature flags).
-   **Monetization Settings**: Adjust subscription pricing or AdMob configurations.

## 5. Deployment

The Admin Panel, being a Flutter Web application, can be deployed to any static web hosting service. Firebase Hosting is recommended for seamless integration with your Firebase project.

### 5.1. Deploying with Firebase Hosting

1.  **Build the Flutter Web Application**:
    Navigate to the `admin_panel` directory and run:
    ```bash
    flutter build web
    ```
    This will generate the web build files in `build/web`.

2.  **Initialize Firebase Hosting**:
    If you haven't already, initialize Firebase Hosting in your project root (`buddy_wellness_app`):
    ```bash
    firebase init hosting
    ```
    -   Select your Firebase project.
    -   For the public directory, enter `admin_panel/build/web`.
    -   Configure as a single-page app: `Yes`.
    -   Set up automatic builds and deploys with GitHub: `No` (unless you want to configure CI/CD).

3.  **Deploy to Firebase Hosting**:
    From the `buddy_wellness_app` directory, deploy your web app:
    ```bash
    firebase deploy --only hosting
    ```
    After successful deployment, Firebase will provide you with a hosting URL.

## 6. Maintenance

-   **Regular Updates**: Keep Flutter SDK and package dependencies updated.
-   **Security Audits**: Periodically review Firebase Security Rules and admin access controls.
-   **Backup Data**: Regularly back up your Firestore data.
