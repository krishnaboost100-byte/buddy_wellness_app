# Buddy Wellness App Architecture

This document outlines the architectural design of the Buddy Wellness application, covering its mobile app, admin panel, and landing website components. The core principle guiding this architecture is **Clean Architecture**, ensuring separation of concerns, testability, and maintainability.

## 1. Overall System Architecture

The Buddy Wellness system is composed of three main applications and a shared backend infrastructure:

-   **Mobile Application (Flutter)**: The primary user-facing application for Android and iOS.
-   **Admin Panel (Flutter Web)**: A web-based interface for administrators to manage users, content, and monitor analytics.
-   **Landing Website (HTML/CSS/JS)**: A static marketing website for user acquisition and information dissemination.
-   **Backend Infrastructure (Firebase)**: A serverless backend providing authentication, database, and cloud functions.

```mermaid
graph TD
    A[Mobile App] --> B(Firebase Authentication)
    A --> C(Firestore Database)
    A --> D(OpenAI API)
    A --> E(AdMob)
    F[Admin Panel] --> B
    F --> C
    G[Landing Website] --> H(Hosting Service)
    B --> C
    C --> D
```

## 2. Mobile Application Architecture (Flutter)

The mobile application follows a layered Clean Architecture approach, dividing the codebase into three main layers: **Presentation**, **Domain**, and **Data**.

```mermaid
graph TD
    P[Presentation Layer] --> D[Domain Layer]
    D --> T[Data Layer]
    T --> F(Firebase Services)
    T --> O(OpenAI Service)
    T --> N(Network Info)

    subgraph Presentation Layer
        UI[Widgets/UI Components]
        PR[Providers/State Management (Riverpod)]
        RO[Routing (GoRouter)]
    end

    subgraph Domain Layer
        UC[Use Cases]
        RE[Repositories (Abstract)]
        EN[Entities]
    end

    subgraph Data Layer
        RM[Remote Data Sources (Firebase/OpenAI)]
        RP[Repositories (Implementation)]
        MD[Models]
    end

    UI --> PR
    PR --> UC
    UC --> RE
    RP --> RM
    RP --> N
    RM --> F
    RM --> O
```

### 2.1. Layers Breakdown

#### 2.1.1. Presentation Layer
-   **Widgets/UI Components**: The visual elements and screens of the application.
-   **Providers/State Management (Riverpod)**: Manages the application state and provides data to the UI. Notifiers interact with use cases from the Domain Layer.
-   **Routing (GoRouter)**: Handles navigation within the application.

#### 2.1.2. Domain Layer
-   **Use Cases**: Contains the application's business logic. Each use case represents a single, specific action that can be performed in the application (e.g., `SignInWithEmailAndPassword`, `GetHabits`). They orchestrate interactions between the Presentation and Data layers.
-   **Repositories (Abstract)**: Defines contracts for data operations. These are abstract classes or interfaces that the Data Layer must implement.
-   **Entities**: Plain Dart objects representing the core business concepts, independent of any data source or UI.

#### 2.1.3. Data Layer
-   **Remote Data Sources**: Handles interactions with external APIs and services (e.g., Firebase Firestore, Firebase Authentication, OpenAI API).
-   **Repositories (Implementation)**: Implements the repository contracts defined in the Domain Layer. They are responsible for fetching data from data sources (remote or local) and mapping it to entities.
-   **Models**: Data structures that mirror the data format from external sources (e.g., Firestore documents) and include methods for converting to/from entities.

### 2.2. Core Services and Utilities

-   **Firebase Service**: Centralized initialization and access to Firebase instances (Auth, Firestore).
-   **Local Storage Service**: Manages local data persistence (e.g., using Hive or SharedPreferences).
-   **OpenAI Service**: Handles communication with the OpenAI API for AI recommendations.
-   **AdMob Service**: Manages the loading and display of advertisements.
-   **Network Info**: Utility for checking internet connectivity.
-   **Dependency Injection (Riverpod)**: Manages the creation and provision of dependencies across the application, ensuring loose coupling and testability.

## 3. Firestore Schema

Firestore is used as the primary NoSQL database. Collections are designed to be scalable and secure, with data partitioned by `userId` where applicable.

### 3.1. `users` Collection
-   **Purpose**: Stores user profiles and authentication-related metadata.
-   **Document ID**: `userId` (from Firebase Authentication `uid`).
-   **Fields**:
    -   `email` (string): User's email address.
    -   `name` (string, optional): User's display name.
    -   `photoUrl` (string, optional): URL to user's profile picture.
    -   `goals` (array of strings, optional): User-defined wellness goals.
    -   `createdAt` (timestamp): Timestamp of user creation.
    -   `updatedAt` (timestamp): Last update timestamp.
    -   `subscriptionStatus` (string, optional): e.g., 

    -   `subscriptionStatus` (string, optional): e.g., 'free', 'premium'.
    -   `lastActive` (timestamp, optional): Last active timestamp.
    -   `selectedLanguage` (string, optional): User's preferred language.
    -   `darkModeEnabled` (boolean, optional): User's dark mode preference.
    -   `isAdmin` (boolean, optional): Flag for admin panel access.

### 3.2. `habits` Collection
-   **Purpose**: Stores individual habit details for each user.
-   **Document ID**: Auto-generated.
-   **Fields**:
    -   `userId` (string): ID of the user who owns the habit.
    -   `name` (string): Name of the habit.
    -   `description` (string): Detailed description of the habit.
    -   `category` (string): e.g., 'Fitness', 'Mindfulness', 'Nutrition'.
    -   `priority` (string): e.g., 'High', 'Medium', 'Low'.
    -   `reminders` (array of maps): List of reminder configurations (e.g., `[{'time': '08:00', 'days': ['Mon', 'Wed']}]`).
    -   `schedule` (map): Defines the habit's recurrence (e.g., `{'type': 'daily', 'value': null}` or `{'type': 'weekly', 'value': ['Mon', 'Fri']}`).
    -   `startDate` (timestamp): Date when the habit started.
    -   `endDate` (timestamp, optional): Date when the habit ended (for archived habits).
    -   `isArchived` (boolean): True if the habit is archived.
    -   `createdAt` (timestamp): Timestamp of habit creation.
    -   `updatedAt` (timestamp): Last update timestamp.

### 3.3. `habit_logs` Collection
-   **Purpose**: Records daily completion status for each habit.
-   **Document ID**: Auto-generated.
-   **Fields**:
    -   `habitId` (string): ID of the habit being logged.
    -   `userId` (string): ID of the user.
    -   `date` (timestamp): Date of completion.
    -   `status` (string): e.g., 'completed', 'skipped', 'failed'.
    -   `createdAt` (timestamp): Timestamp of log creation.

### 3.4. `ai_recommendations` Collection
-   **Purpose**: Stores personalized AI recommendations generated for users.
-   **Document ID**: Auto-generated.
-   **Fields**:
    -   `userId` (string): ID of the user.
    -   `recommendationText` (string): The AI-generated recommendation.
    -   `category` (string): e.g., 'Wellness', 'Productivity', 'Mindfulness'.
    -   `createdAt` (timestamp): Timestamp of recommendation generation.
    -   `isRead` (boolean): True if the user has read the recommendation.

### 3.5. `streaks` Collection
-   **Purpose**: Tracks user streaks for habits or overall wellness.
-   **Document ID**: Auto-generated (or `userId` for overall streak, `habitId` for habit-specific).
-   **Fields**:
    -   `userId` (string): ID of the user.
    -   `habitId` (string, optional): ID of the habit (if habit-specific streak).
    -   `type` (string): e.g., 'daily', 'overall'.
    -   `currentStreak` (integer): Current consecutive streak count.
    -   `longestStreak` (integer): Longest streak achieved.
    -   `lastCompletionDate` (timestamp): Date of the last completion that extended the streak.
    -   `updatedAt` (timestamp): Last update timestamp.

### 3.6. `analytics` Collection
-   **Purpose**: Stores aggregated analytics data for users.
-   **Document ID**: Auto-generated.
-   **Fields**:
    -   `userId` (string): ID of the user.
    -   `date` (timestamp): Date for which analytics are recorded.
    -   `wellnessScore` (integer): Daily wellness score.
    -   `mood` (string): User's reported mood.
    -   `habitCompletionRates` (map): `{'habitId': percentage}`.
    -   `productivityScore` (integer): Daily productivity score.
    -   `insights` (array of strings): Key insights for the day.

### 3.7. `app_settings` Collection
-   **Purpose**: Stores user-specific application settings.
-   **Document ID**: `userId`.
-   **Fields**:
    -   `darkMode` (boolean): User's dark mode preference.
    -   `language` (string): User's preferred language (e.g., 'en', 'es').
    -   `notificationPreferences` (map): `{'habitReminders': true, 'aiAlerts': false}`.
    -   `privacyControls` (map): `{'dataSharing': true, 'personalization': true}`.

### 3.8. `notifications` Collection
-   **Purpose**: Stores scheduled and sent notifications for users.
-   **Document ID**: Auto-generated.
-   **Fields**:
    -   `userId` (string, optional): ID of the target user (if user-specific).
    -   `title` (string): Notification title.
    -   `body` (string): Notification message.
    -   `type` (string): e.g., 'habit_reminder', 'ai_insight', 'promotional'.
    -   `scheduledAt` (timestamp): When the notification is scheduled to be sent.
    -   `sentAt` (timestamp, optional): When the notification was actually sent.
    -   `isRead` (boolean): True if the user has read the notification.
    -   `targetScreen` (string, optional): Deep link or route to navigate to when notification is tapped.

## 4. Firebase Security Rules

Firebase Security Rules are crucial for protecting data in Firestore. The rules are designed to ensure that users can only access and modify their own data, and administrators have broader access.

```firestore
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Allow read/write access to authenticated users for their own data
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }

    match /habits/{habitId} {
      allow read, write: if request.auth != null && request.auth.uid == resource.data.userId;
    }

    match /habit_logs/{logId} {
      allow read, write: if request.auth != null && request.auth.uid == resource.data.userId;
    }

    match /ai_recommendations/{recommendationId} {
      allow read, write: if request.auth != null && request.auth.uid == resource.data.userId;
    }

    match /streaks/{streakId} {
      allow read, write: if request.auth != null && request.auth.uid == resource.data.userId;
    }

    match /analytics/{analyticsId} {
      allow read, write: if request.auth != null && request.auth.uid == resource.data.userId;
    }

    match /app_settings/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }

    match /notifications/{notificationId} {
      allow read, write: if request.auth != null && request.auth.uid == resource.data.userId;
    }

    // Admin access (for future admin panel implementation)
    // This assumes an 'admin' field in the user document.
    // For a more robust solution, consider custom claims.
    match /{document=**} {
      allow read, write: if request.auth != null && get(/databases/$(database)/documents/users/$(request.auth.uid)).data.isAdmin == true;
    }
  }
}
```

## 5. Monetization Strategy

The application will implement a freemium model with an optional premium subscription. AdMob will be integrated for displaying banner and interstitial ads to free users.

### 5.1. Subscription Tiers
-   **Free Tier**: Basic habit tracking, limited habits, basic analytics, and ad-supported.
-   **Premium Tier**: Unlimited habits, advanced analytics, AI recommendations, ad-free experience, and priority support.

### 5.2. AdMob Integration
-   **Banner Ads**: Displayed at the bottom of certain screens in the mobile app for free users.
-   **Interstitial Ads**: Shown at natural transition points within the app (e.g., after completing a habit, navigating between major sections) for free users.

## 6. CI/CD Strategy

Continuous Integration and Continuous Deployment (CI/CD) will be implemented to automate the build, test, and deployment processes for all components of the application.

### 6.1. Mobile App (Flutter)
-   **CI**: Automated builds and tests (unit, widget, integration) on every push to the repository.
-   **CD**: Automated deployment to Firebase App Distribution for internal testing and to Google Play Store and Apple App Store for production releases.

### 6.2. Admin Panel (Flutter Web)
-   **CI**: Automated builds and tests.
-   **CD**: Automated deployment to Firebase Hosting or a similar static site hosting service.

### 6.3. Landing Website
-   **CI**: Automated builds (if any static site generator is used) and linting.
-   **CD**: Automated deployment to a static site hosting service (e.g., Netlify, Vercel, Firebase Hosting).

## 7. Future Considerations
-   **Cloud Functions**: For complex backend logic, scheduled tasks, or integrating with other services.
-   **Advanced AI**: Exploring more sophisticated AI models for deeper insights and personalized coaching.
-   **Wearable Integration**: Connecting with smartwatches and fitness trackers for automated data collection.
-   **Community Features**: Social features for sharing progress and challenges.
