# Buddy Wellness App API Documentation

This document provides an overview of the internal API structure and external API integrations used within the Buddy Wellness application. The internal API refers to the interaction patterns between the different layers of the Flutter application (Presentation, Domain, Data), while external APIs are third-party services like Firebase and OpenAI.

## 1. Internal API (Clean Architecture)

The internal API adheres to the principles of Clean Architecture, primarily through the use of **Use Cases** in the Domain Layer. These use cases define the application's business logic and serve as the API for the Presentation Layer to interact with the core functionalities.

### 1.1. Use Case Structure

Each use case typically follows a similar structure:

```dart
import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/usecases/usecase.dart';
import '../repositories/some_repository.dart';

class SomeUseCase implements UseCase<ReturnType, ParamsType> {
  final SomeRepository repository;

  SomeUseCase(this.repository);

  @override
  Future<Either<Failure, ReturnType>> call(ParamsType params) async {
    return await repository.someMethod(params);
  }
}

class ParamsType extends Equatable {
  final String someProperty;

  const ParamsType({required this.someProperty});

  @override
  List<Object> get props => [someProperty];
}
```

-   **`UseCase<ReturnType, ParamsType>`**: An abstract class defining the contract for all use cases. `ReturnType` is the type of data returned by the use case, and `ParamsType` is the type of parameters it accepts.
-   **`Either<Failure, ReturnType>`**: The return type for all use cases, indicating either a `Failure` (left side) or the `ReturnType` (right side) using the `dartz` package for functional error handling.
-   **`SomeRepository`**: An abstract repository interface from the Domain Layer, which the use case interacts with to perform data operations.

### 1.2. Key Use Cases

| Feature             | Use Case Name                      | Description                                                                 |
| :------------------ | :--------------------------------- | :-------------------------------------------------------------------------- |
| **Authentication**  | `SignInWithEmailAndPassword`       | Authenticates a user with email and password.                               |
|                     | `SignUpWithEmailAndPassword`       | Registers a new user with email and password.                               |
|                     | `SignOut`                          | Logs out the current user.                                                  |
| **Dashboard**       | `GetDashboardData`                 | Retrieves aggregated data for the user dashboard.                           |
| **Habit Management**| `CreateHabit`                      | Creates a new habit for the user.                                           |
|                     | `GetHabits`                        | Retrieves all habits for the current user.                                  |
|                     | `UpdateHabit`                      | Updates an existing habit.                                                  |
|                     | `DeleteHabit`                      | Deletes a habit.                                                            |
| **AI Recommendations**| `GetAIRecommendations`             | Fetches AI-generated wellness recommendations.                              |
|                     | `GenerateAIRecommendation`         | Triggers the generation of a new AI recommendation.                         |
| **Streak System**   | `GetStreaks`                       | Retrieves all streaks for the user.                                         |
|                     | `GetStreakById`                    | Retrieves a specific streak by ID.                                          |
|                     | `CreateOrUpdateStreak`             | Creates a new streak or updates an existing one.                            |
| **Analytics**       | `GetAnalyticsData`                 | Fetches historical analytics data for the user.                             |
|                     | `SaveAnalyticsData`                | Saves analytics data for a specific period.                                 |
| **User Profile**    | `GetUserProfile`                   | Retrieves the current user's profile information.                           |
|                     | `UpdateUserProfile`                | Updates the current user's profile information.                             |
|                     | `DeleteUserAccount`                | Deletes the user's account and associated data.                             |
| **Settings**        | `GetSettings`                      | Retrieves user-specific application settings.                               |
|                     | `UpdateSettings`                   | Updates user-specific application settings.                                 |
| **Notifications**   | `GetNotifications`                 | Fetches all notifications for the user.                                     |
|                     | `MarkNotificationAsRead`           | Marks a specific notification as read.                                      |
|                     | `SendNotification`                 | Sends a notification (primarily for internal system use or admin panel).    |

## 2. External API Integrations

### 2.1. Firebase

Firebase serves as the primary Backend-as-a-Service (BaaS) for the Buddy Wellness application. It provides various services accessed via its SDKs.

| Firebase Service    | Purpose                                                                 | Integration Point                                                               |
| :------------------ | :---------------------------------------------------------------------- | :------------------------------------------------------------------------------ |
| **Authentication**  | User registration, login, and session management.                       | `AuthRemoteDataSource` (Data Layer)                                             |
| **Firestore**       | NoSQL database for storing user data, habits, streaks, etc.             | `AuthRemoteDataSource`, `DashboardRemoteDataSource`, `HabitRemoteDataSource`, etc. (Data Layer) |
| **Cloud Storage**   | Storing user-generated content like profile pictures.                   | `UserProfileRemoteDataSource` (Data Layer)                                      |
| **Cloud Messaging** | Sending push notifications to users.                                    | `NotificationRemoteDataSource` (Data Layer)                                     |
| **Analytics**       | Tracking user behavior and app usage.                                   | Integrated directly via Firebase SDK, `AnalyticsRemoteDataSource` (Data Layer)  |
| **Remote Config**   | Dynamic configuration of app features without app updates.              | Integrated directly via Firebase SDK                                            |
| **Crashlytics**     | Real-time crash reporting.                                              | Integrated directly via Firebase SDK                                            |

### 2.2. OpenAI API

OpenAI API is used to power the AI Recommendations feature, providing personalized insights and suggestions to users.

| OpenAI Service      | Purpose                                                                 | Integration Point                                                               |
| :------------------ | :---------------------------------------------------------------------- | :------------------------------------------------------------------------------ |
| **GPT Models**      | Generating personalized wellness recommendations based on user data.    | `AIRecommendationRemoteDataSource` (Data Layer) via `OpenAIService`             |

### 2.3. Google Mobile Ads (AdMob)

AdMob is integrated to display advertisements, supporting the freemium monetization model.

| AdMob Component     | Purpose                                                                 | Integration Point                                                               |
| :------------------ | :---------------------------------------------------------------------- | :------------------------------------------------------------------------------ |
| **Banner Ads**      | Displaying banner advertisements in the mobile app.                     | `AdMobService` (Services Layer)                                                 |
| **Interstitial Ads**| Displaying full-screen interstitial advertisements at natural breaks.   | `AdMobService` (Services Layer)                                                 |

## 3. API Security Considerations

-   **Firebase Security Rules**: Implemented to ensure data access control at the database level (see [Architecture Document](docs/architecture.md)).
-   **API Key Management**: OpenAI API keys and AdMob unit IDs are managed securely. For client-side applications, these keys are typically embedded but should be restricted to prevent abuse (e.g., API key restrictions).
-   **Authentication**: All sensitive operations require user authentication via Firebase Authentication.
-   **Data Validation**: Input validation is performed at the application level before interacting with external APIs.
