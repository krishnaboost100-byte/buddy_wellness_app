# Buddy Wellness App Monetization Strategy

This document outlines the monetization strategy for the Buddy Wellness application, focusing on a freemium model with an optional premium subscription and integrated advertising through Google AdMob.

## 1. Freemium Model

The Buddy Wellness app will operate on a freemium model, offering a free version with core functionalities and a premium subscription that unlocks advanced features and an ad-free experience.

### 1.1. Free Tier Features

-   **Basic Habit Tracking**: Users can create and track a limited number of habits (e.g., up to 5).
-   **Basic Analytics**: Access to fundamental progress tracking and historical data.
-   **Ad-Supported**: The free version will display advertisements to users.

### 1.2. Premium Tier Features

-   **Unlimited Habits**: Users can create and track an unlimited number of habits.
-   **Advanced Analytics**: Access to in-depth insights, customizable reports, and more detailed wellness metrics.
-   **AI Recommendations**: Personalized wellness recommendations and insights powered by AI.
-   **Ad-Free Experience**: No advertisements will be displayed to premium subscribers.
-   **Priority Support**: Expedited customer support for premium users.
-   **Exclusive Content/Features**: Potential for future exclusive content or features (e.g., guided meditations, advanced goal setting).

### 1.3. Subscription Pricing

-   **Monthly Subscription**: e.g., $4.99/month
-   **Annual Subscription**: e.g., $49.99/year (offering a discount compared to monthly)

Pricing will be subject to market research and A/B testing to optimize conversion rates.

## 2. Google AdMob Integration

AdMob will be used to display advertisements within the free version of the mobile application. This provides a revenue stream from non-subscribing users.

### 2.1. Ad Types and Placement

-   **Banner Ads**: Small rectangular ads displayed at the top or bottom of the screen. These will be integrated into less intrusive areas of the app, such as the bottom of the dashboard or habit list screens.
-   **Interstitial Ads**: Full-screen ads that appear at natural transition points in the user flow. These will be strategically placed to minimize disruption, for example:
    -   After a user completes a habit for the day.
    -   When navigating between major sections of the app (e.g., from Dashboard to Analytics).
    -   After a certain number of actions within the app.

### 2.2. Implementation Details

-   **`google_mobile_ads` Package**: The official Flutter package for AdMob integration is used.
-   **`AdMobService`**: A dedicated service class (`lib/services/admob_service.dart`) handles the loading and displaying of ads, abstracting the AdMob SDK details from the UI.
-   **Ad Unit IDs**: Placeholder ad unit IDs are provided in `AdMobService`. These **MUST** be replaced with actual AdMob ad unit IDs from your AdMob account before deploying to production.
    -   `ca-app-pub-xxxxxxxxxxxxxxxx/yyyyyyyyyy` for banner ads.
    -   `ca-app-pub-xxxxxxxxxxxxxxxx/zzzzzzzzzz` for interstitial ads.
-   **User Consent**: Ensure compliance with privacy regulations (e.g., GDPR, CCPA) by implementing a user consent mechanism for personalized ads.

## 3. Future Monetization Opportunities

-   **In-App Purchases (One-time)**: Offering one-time purchases for specific digital goods or features (e.g., premium themes, custom icon packs).
-   **Affiliate Marketing**: Partnering with wellness brands to promote relevant products or services.
-   **Premium Content**: Offering exclusive articles, guided programs, or coaching sessions as part of the premium subscription.
-   **API Access**: Potentially offering API access for third-party integrations or data analysis (for advanced use cases).
